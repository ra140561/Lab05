/**
 */
package Model;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see Model.ModelFactory
 * @model kind="package"
 * @generated
 */
public interface ModelPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "Model";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http:///Model.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "Model";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ModelPackage eINSTANCE = Model.impl.ModelPackageImpl.init();

	/**
	 * The meta object id for the '{@link Model.impl.TerminalImpl <em>Terminal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.TerminalImpl
	 * @see Model.impl.ModelPackageImpl#getTerminal()
	 * @generated
	 */
	int TERMINAL = 0;

	/**
	 * The feature id for the '<em><b>Session Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERMINAL__SESSION_NAME = 0;

	/**
	 * The number of structural features of the '<em>Terminal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERMINAL_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Authentication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERMINAL___AUTHENTICATION__STRING_STRING = 0;

	/**
	 * The operation id for the '<em>Check Availability</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERMINAL___CHECK_AVAILABILITY__INT_STRING = 1;

	/**
	 * The number of operations of the '<em>Terminal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TERMINAL_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link Model.impl.BibliotecaImpl <em>Biblioteca</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.BibliotecaImpl
	 * @see Model.impl.ModelPackageImpl#getBiblioteca()
	 * @generated
	 */
	int BIBLIOTECA = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIBLIOTECA__NAME = 0;

	/**
	 * The feature id for the '<em><b>Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIBLIOTECA__ADDRESS = 1;

	/**
	 * The feature id for the '<em><b>System Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIBLIOTECA__SYSTEM_DATE = 2;

	/**
	 * The number of structural features of the '<em>Biblioteca</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIBLIOTECA_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Get System Date</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIBLIOTECA___GET_SYSTEM_DATE__STRING = 0;

	/**
	 * The number of operations of the '<em>Biblioteca</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIBLIOTECA_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link Model.impl.EmprestimoImpl <em>Emprestimo</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.EmprestimoImpl
	 * @see Model.impl.ModelPackageImpl#getEmprestimo()
	 * @generated
	 */
	int EMPRESTIMO = 2;

	/**
	 * The feature id for the '<em><b>Devolution Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO__DEVOLUTION_DATE = 0;

	/**
	 * The feature id for the '<em><b>Borrow Protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO__BORROW_PROTOCOL = 1;

	/**
	 * The number of structural features of the '<em>Emprestimo</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO_FEATURE_COUNT = 2;

	/**
	 * The operation id for the '<em>Get Devollution Charges</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO___GET_DEVOLLUTION_CHARGES__INT = 0;

	/**
	 * The operation id for the '<em>Is Avaiable</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO___IS_AVAIABLE__INT = 1;

	/**
	 * The operation id for the '<em>Set Devolution Date</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO___SET_DEVOLUTION_DATE = 2;

	/**
	 * The operation id for the '<em>Set Borrow Protocol</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO___SET_BORROW_PROTOCOL = 3;

	/**
	 * The operation id for the '<em>Cancel Reservation</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO___CANCEL_RESERVATION__INT = 4;

	/**
	 * The operation id for the '<em>Add Reservation</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO___ADD_RESERVATION__INT = 5;

	/**
	 * The operation id for the '<em>Set Charges</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO___SET_CHARGES = 6;

	/**
	 * The number of operations of the '<em>Emprestimo</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPRESTIMO_OPERATION_COUNT = 7;

	/**
	 * The meta object id for the '{@link Model.impl.ExemplarImpl <em>Exemplar</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.ExemplarImpl
	 * @see Model.impl.ModelPackageImpl#getExemplar()
	 * @generated
	 */
	int EXEMPLAR = 3;

	/**
	 * The feature id for the '<em><b>Autores</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXEMPLAR__AUTORES = 0;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXEMPLAR__TITULO = 1;

	/**
	 * The feature id for the '<em><b>Availability</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXEMPLAR__AVAILABILITY = 2;

	/**
	 * The feature id for the '<em><b>Lib Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXEMPLAR__LIB_NUMBER = 3;

	/**
	 * The feature id for the '<em><b>Is Blocked</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXEMPLAR__IS_BLOCKED = 4;

	/**
	 * The number of structural features of the '<em>Exemplar</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXEMPLAR_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Update Copies</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXEMPLAR___UPDATE_COPIES__INT = 0;

	/**
	 * The operation id for the '<em>Block</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXEMPLAR___BLOCK__INT = 1;

	/**
	 * The operation id for the '<em>Unblock</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXEMPLAR___UNBLOCK__INT = 2;

	/**
	 * The number of operations of the '<em>Exemplar</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXEMPLAR_OPERATION_COUNT = 3;

	/**
	 * The meta object id for the '{@link Model.impl.PublicacaoImpl <em>Publicacao</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.PublicacaoImpl
	 * @see Model.impl.ModelPackageImpl#getPublicacao()
	 * @generated
	 */
	int PUBLICACAO = 4;

	/**
	 * The feature id for the '<em><b>Lib Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUBLICACAO__LIB_NUMBER = 0;

	/**
	 * The number of structural features of the '<em>Publicacao</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUBLICACAO_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Add New Publication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUBLICACAO___ADD_NEW_PUBLICATION__INT = 0;

	/**
	 * The operation id for the '<em>Remove Publication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUBLICACAO___REMOVE_PUBLICATION__INT = 1;

	/**
	 * The operation id for the '<em>Get Libnumber</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUBLICACAO___GET_LIBNUMBER = 2;

	/**
	 * The operation id for the '<em>Set Libnumber</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUBLICACAO___SET_LIBNUMBER = 3;

	/**
	 * The number of operations of the '<em>Publicacao</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUBLICACAO_OPERATION_COUNT = 4;

	/**
	 * The meta object id for the '{@link Model.impl.LivroImpl <em>Livro</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.LivroImpl
	 * @see Model.impl.ModelPackageImpl#getLivro()
	 * @generated
	 */
	int LIVRO = 5;

	/**
	 * The feature id for the '<em><b>Lib Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO__LIB_NUMBER = PUBLICACAO__LIB_NUMBER;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO__TITULO = PUBLICACAO_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Autores</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO__AUTORES = PUBLICACAO_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Is Borrowed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO__IS_BORROWED = PUBLICACAO_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Livro</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO_FEATURE_COUNT = PUBLICACAO_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Add New Publication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO___ADD_NEW_PUBLICATION__INT = PUBLICACAO___ADD_NEW_PUBLICATION__INT;

	/**
	 * The operation id for the '<em>Remove Publication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO___REMOVE_PUBLICATION__INT = PUBLICACAO___REMOVE_PUBLICATION__INT;

	/**
	 * The operation id for the '<em>Get Libnumber</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO___GET_LIBNUMBER = PUBLICACAO___GET_LIBNUMBER;

	/**
	 * The operation id for the '<em>Set Libnumber</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO___SET_LIBNUMBER = PUBLICACAO___SET_LIBNUMBER;

	/**
	 * The operation id for the '<em>Get Info</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO___GET_INFO__INT = PUBLICACAO_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Set Info</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO___SET_INFO__INT = PUBLICACAO_OPERATION_COUNT + 1;

	/**
	 * The number of operations of the '<em>Livro</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIVRO_OPERATION_COUNT = PUBLICACAO_OPERATION_COUNT + 2;

	/**
	 * The meta object id for the '{@link Model.impl.PeriodicoImpl <em>Periodico</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.PeriodicoImpl
	 * @see Model.impl.ModelPackageImpl#getPeriodico()
	 * @generated
	 */
	int PERIODICO = 6;

	/**
	 * The feature id for the '<em><b>Lib Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO__LIB_NUMBER = PUBLICACAO__LIB_NUMBER;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO__TITULO = PUBLICACAO_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Autores</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO__AUTORES = PUBLICACAO_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Is Borrowed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO__IS_BORROWED = PUBLICACAO_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Periodico</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO_FEATURE_COUNT = PUBLICACAO_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Add New Publication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO___ADD_NEW_PUBLICATION__INT = PUBLICACAO___ADD_NEW_PUBLICATION__INT;

	/**
	 * The operation id for the '<em>Remove Publication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO___REMOVE_PUBLICATION__INT = PUBLICACAO___REMOVE_PUBLICATION__INT;

	/**
	 * The operation id for the '<em>Get Libnumber</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO___GET_LIBNUMBER = PUBLICACAO___GET_LIBNUMBER;

	/**
	 * The operation id for the '<em>Set Libnumber</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO___SET_LIBNUMBER = PUBLICACAO___SET_LIBNUMBER;

	/**
	 * The operation id for the '<em>Get Info</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO___GET_INFO__INT = PUBLICACAO_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Set Info</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO___SET_INFO__INT = PUBLICACAO_OPERATION_COUNT + 1;

	/**
	 * The number of operations of the '<em>Periodico</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERIODICO_OPERATION_COUNT = PUBLICACAO_OPERATION_COUNT + 2;

	/**
	 * The meta object id for the '{@link Model.impl.TeseImpl <em>Tese</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.TeseImpl
	 * @see Model.impl.ModelPackageImpl#getTese()
	 * @generated
	 */
	int TESE = 7;

	/**
	 * The feature id for the '<em><b>Lib Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE__LIB_NUMBER = PUBLICACAO__LIB_NUMBER;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE__TITULO = PUBLICACAO_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Is Borrowed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE__IS_BORROWED = PUBLICACAO_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Autores</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE__AUTORES = PUBLICACAO_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Tese</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE_FEATURE_COUNT = PUBLICACAO_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Add New Publication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE___ADD_NEW_PUBLICATION__INT = PUBLICACAO___ADD_NEW_PUBLICATION__INT;

	/**
	 * The operation id for the '<em>Remove Publication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE___REMOVE_PUBLICATION__INT = PUBLICACAO___REMOVE_PUBLICATION__INT;

	/**
	 * The operation id for the '<em>Get Libnumber</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE___GET_LIBNUMBER = PUBLICACAO___GET_LIBNUMBER;

	/**
	 * The operation id for the '<em>Set Libnumber</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE___SET_LIBNUMBER = PUBLICACAO___SET_LIBNUMBER;

	/**
	 * The operation id for the '<em>Get Info</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE___GET_INFO__INT = PUBLICACAO_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Set Info</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE___SET_INFO__INT = PUBLICACAO_OPERATION_COUNT + 1;

	/**
	 * The number of operations of the '<em>Tese</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESE_OPERATION_COUNT = PUBLICACAO_OPERATION_COUNT + 2;

	/**
	 * The meta object id for the '{@link Model.impl.ManualImpl <em>Manual</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.ManualImpl
	 * @see Model.impl.ModelPackageImpl#getManual()
	 * @generated
	 */
	int MANUAL = 8;

	/**
	 * The feature id for the '<em><b>Lib Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL__LIB_NUMBER = PUBLICACAO__LIB_NUMBER;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL__TITULO = PUBLICACAO_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Autores</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL__AUTORES = PUBLICACAO_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Is Borrowed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL__IS_BORROWED = PUBLICACAO_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Manual</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL_FEATURE_COUNT = PUBLICACAO_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Add New Publication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL___ADD_NEW_PUBLICATION__INT = PUBLICACAO___ADD_NEW_PUBLICATION__INT;

	/**
	 * The operation id for the '<em>Remove Publication</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL___REMOVE_PUBLICATION__INT = PUBLICACAO___REMOVE_PUBLICATION__INT;

	/**
	 * The operation id for the '<em>Get Libnumber</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL___GET_LIBNUMBER = PUBLICACAO___GET_LIBNUMBER;

	/**
	 * The operation id for the '<em>Set Libnumber</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL___SET_LIBNUMBER = PUBLICACAO___SET_LIBNUMBER;

	/**
	 * The operation id for the '<em>Get Info</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL___GET_INFO__INT = PUBLICACAO_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Set Info</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL___SET_INFO__INT = PUBLICACAO_OPERATION_COUNT + 1;

	/**
	 * The number of operations of the '<em>Manual</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MANUAL_OPERATION_COUNT = PUBLICACAO_OPERATION_COUNT + 2;

	/**
	 * The meta object id for the '{@link Model.impl.UsuarioImpl <em>Usuario</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.UsuarioImpl
	 * @see Model.impl.ModelPackageImpl#getUsuario()
	 * @generated
	 */
	int USUARIO = 9;

	/**
	 * The feature id for the '<em><b>CPF</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO__CPF = 0;

	/**
	 * The feature id for the '<em><b>First Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO__FIRST_NAME = 1;

	/**
	 * The feature id for the '<em><b>Last Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO__LAST_NAME = 2;

	/**
	 * The feature id for the '<em><b>Full Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO__FULL_NAME = 3;

	/**
	 * The feature id for the '<em><b>Charges Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO__CHARGES_STATUS = 4;

	/**
	 * The number of structural features of the '<em>Usuario</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Register User At Data Base</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO___REGISTER_USER_AT_DATA_BASE__INT = 0;

	/**
	 * The operation id for the '<em>Set Charge Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO___SET_CHARGE_STATUS__INT = 1;

	/**
	 * The number of operations of the '<em>Usuario</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link Model.impl.AlunoImpl <em>Aluno</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.AlunoImpl
	 * @see Model.impl.ModelPackageImpl#getAluno()
	 * @generated
	 */
	int ALUNO = 10;

	/**
	 * The feature id for the '<em><b>CPF</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO__CPF = USUARIO__CPF;

	/**
	 * The feature id for the '<em><b>First Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO__FIRST_NAME = USUARIO__FIRST_NAME;

	/**
	 * The feature id for the '<em><b>Last Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO__LAST_NAME = USUARIO__LAST_NAME;

	/**
	 * The feature id for the '<em><b>Full Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO__FULL_NAME = USUARIO__FULL_NAME;

	/**
	 * The feature id for the '<em><b>Charges Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO__CHARGES_STATUS = USUARIO__CHARGES_STATUS;

	/**
	 * The feature id for the '<em><b>Email</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO__EMAIL = USUARIO_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO__ADDRESS = USUARIO_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>CEP</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO__CEP = USUARIO_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Aluno</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO_FEATURE_COUNT = USUARIO_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Register User At Data Base</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___REGISTER_USER_AT_DATA_BASE__INT = USUARIO___REGISTER_USER_AT_DATA_BASE__INT;

	/**
	 * The operation id for the '<em>Set Charge Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___SET_CHARGE_STATUS__INT = USUARIO___SET_CHARGE_STATUS__INT;

	/**
	 * The operation id for the '<em>Get First Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___GET_FIRST_NAME = USUARIO_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Set Full Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___SET_FULL_NAME = USUARIO_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>To Register Student</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___TO_REGISTER_STUDENT__INT = USUARIO_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Get Last Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___GET_LAST_NAME = USUARIO_OPERATION_COUNT + 3;

	/**
	 * The operation id for the '<em>Set CPF</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___SET_CPF = USUARIO_OPERATION_COUNT + 4;

	/**
	 * The operation id for the '<em>Set CEP</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___SET_CEP = USUARIO_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>CALL Form</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___CALL_FORM = USUARIO_OPERATION_COUNT + 6;

	/**
	 * The operation id for the '<em>Get Cep</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___GET_CEP = USUARIO_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Get CPF</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___GET_CPF = USUARIO_OPERATION_COUNT + 8;

	/**
	 * The operation id for the '<em>Set Full Address</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO___SET_FULL_ADDRESS = USUARIO_OPERATION_COUNT + 9;

	/**
	 * The number of operations of the '<em>Aluno</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALUNO_OPERATION_COUNT = USUARIO_OPERATION_COUNT + 10;

	/**
	 * The meta object id for the '{@link Model.impl.ProfessorImpl <em>Professor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.ProfessorImpl
	 * @see Model.impl.ModelPackageImpl#getProfessor()
	 * @generated
	 */
	int PROFESSOR = 11;

	/**
	 * The feature id for the '<em><b>CPF</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR__CPF = USUARIO__CPF;

	/**
	 * The feature id for the '<em><b>First Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR__FIRST_NAME = USUARIO__FIRST_NAME;

	/**
	 * The feature id for the '<em><b>Last Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR__LAST_NAME = USUARIO__LAST_NAME;

	/**
	 * The feature id for the '<em><b>Full Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR__FULL_NAME = USUARIO__FULL_NAME;

	/**
	 * The feature id for the '<em><b>Charges Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR__CHARGES_STATUS = USUARIO__CHARGES_STATUS;

	/**
	 * The feature id for the '<em><b>Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR__ADDRESS = USUARIO_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Email</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR__EMAIL = USUARIO_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>CEP</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR__CEP = USUARIO_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Professor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR_FEATURE_COUNT = USUARIO_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Register User At Data Base</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___REGISTER_USER_AT_DATA_BASE__INT = USUARIO___REGISTER_USER_AT_DATA_BASE__INT;

	/**
	 * The operation id for the '<em>Set Charge Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___SET_CHARGE_STATUS__INT = USUARIO___SET_CHARGE_STATUS__INT;

	/**
	 * The operation id for the '<em>Set CEP</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___SET_CEP = USUARIO_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Get Last Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___GET_LAST_NAME = USUARIO_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Get First Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___GET_FIRST_NAME = USUARIO_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Set Full Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___SET_FULL_NAME = USUARIO_OPERATION_COUNT + 3;

	/**
	 * The operation id for the '<em>To Register Professor</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___TO_REGISTER_PROFESSOR__INT = USUARIO_OPERATION_COUNT + 4;

	/**
	 * The operation id for the '<em>Set CPF</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___SET_CPF = USUARIO_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>CALL Form</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___CALL_FORM = USUARIO_OPERATION_COUNT + 6;

	/**
	 * The operation id for the '<em>Get Cep</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___GET_CEP = USUARIO_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Get CPF</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___GET_CPF = USUARIO_OPERATION_COUNT + 8;

	/**
	 * The operation id for the '<em>Set Full Address</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR___SET_FULL_ADDRESS = USUARIO_OPERATION_COUNT + 9;

	/**
	 * The number of operations of the '<em>Professor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFESSOR_OPERATION_COUNT = USUARIO_OPERATION_COUNT + 10;

	/**
	 * The meta object id for the '{@link Model.impl.FuncionarioImpl <em>Funcionario</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.FuncionarioImpl
	 * @see Model.impl.ModelPackageImpl#getFuncionario()
	 * @generated
	 */
	int FUNCIONARIO = 12;

	/**
	 * The feature id for the '<em><b>CPF</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO__CPF = USUARIO__CPF;

	/**
	 * The feature id for the '<em><b>First Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO__FIRST_NAME = USUARIO__FIRST_NAME;

	/**
	 * The feature id for the '<em><b>Last Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO__LAST_NAME = USUARIO__LAST_NAME;

	/**
	 * The feature id for the '<em><b>Full Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO__FULL_NAME = USUARIO__FULL_NAME;

	/**
	 * The feature id for the '<em><b>Charges Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO__CHARGES_STATUS = USUARIO__CHARGES_STATUS;

	/**
	 * The feature id for the '<em><b>CEP</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO__CEP = USUARIO_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Email</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO__EMAIL = USUARIO_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO__ADDRESS = USUARIO_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Funcionario</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO_FEATURE_COUNT = USUARIO_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Register User At Data Base</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___REGISTER_USER_AT_DATA_BASE__INT = USUARIO___REGISTER_USER_AT_DATA_BASE__INT;

	/**
	 * The operation id for the '<em>Set Charge Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___SET_CHARGE_STATUS__INT = USUARIO___SET_CHARGE_STATUS__INT;

	/**
	 * The operation id for the '<em>Set Full Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___SET_FULL_NAME = USUARIO_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Set CEP</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___SET_CEP = USUARIO_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Set CPF</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___SET_CPF = USUARIO_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>To Register Employee</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___TO_REGISTER_EMPLOYEE__INT = USUARIO_OPERATION_COUNT + 3;

	/**
	 * The operation id for the '<em>Get First Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___GET_FIRST_NAME = USUARIO_OPERATION_COUNT + 4;

	/**
	 * The operation id for the '<em>Get Last Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___GET_LAST_NAME = USUARIO_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>CALL Form</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___CALL_FORM = USUARIO_OPERATION_COUNT + 6;

	/**
	 * The operation id for the '<em>Get Cep</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___GET_CEP = USUARIO_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Set Full Address</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___SET_FULL_ADDRESS = USUARIO_OPERATION_COUNT + 8;

	/**
	 * The operation id for the '<em>Get CPF</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO___GET_CPF = USUARIO_OPERATION_COUNT + 9;

	/**
	 * The number of operations of the '<em>Funcionario</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCIONARIO_OPERATION_COUNT = USUARIO_OPERATION_COUNT + 10;

	/**
	 * The meta object id for the '{@link Model.impl.DepartamentosImpl <em>Departamentos</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.DepartamentosImpl
	 * @see Model.impl.ModelPackageImpl#getDepartamentos()
	 * @generated
	 */
	int DEPARTAMENTOS = 14;

	/**
	 * The number of structural features of the '<em>Departamentos</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTAMENTOS_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Departamentos</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTAMENTOS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link Model.impl.DeptoAImpl <em>Depto A</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.DeptoAImpl
	 * @see Model.impl.ModelPackageImpl#getDeptoA()
	 * @generated
	 */
	int DEPTO_A = 13;

	/**
	 * The feature id for the '<em><b>Dept Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTO_A__DEPT_NAME = DEPARTAMENTOS_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Depto A</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTO_A_FEATURE_COUNT = DEPARTAMENTOS_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Get Deptname</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTO_A___GET_DEPTNAME = DEPARTAMENTOS_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Set Dept Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTO_A___SET_DEPT_NAME = DEPARTAMENTOS_OPERATION_COUNT + 1;

	/**
	 * The number of operations of the '<em>Depto A</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTO_A_OPERATION_COUNT = DEPARTAMENTOS_OPERATION_COUNT + 2;

	/**
	 * The meta object id for the '{@link Model.impl.DeptoBImpl <em>Depto B</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Model.impl.DeptoBImpl
	 * @see Model.impl.ModelPackageImpl#getDeptoB()
	 * @generated
	 */
	int DEPTO_B = 15;

	/**
	 * The feature id for the '<em><b>Dept Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTO_B__DEPT_NAME = DEPARTAMENTOS_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Depto B</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTO_B_FEATURE_COUNT = DEPARTAMENTOS_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Get Deptname</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTO_B___GET_DEPTNAME = DEPARTAMENTOS_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Set Dept Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTO_B___SET_DEPT_NAME = DEPARTAMENTOS_OPERATION_COUNT + 1;

	/**
	 * The number of operations of the '<em>Depto B</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTO_B_OPERATION_COUNT = DEPARTAMENTOS_OPERATION_COUNT + 2;


	/**
	 * Returns the meta object for class '{@link Model.Terminal <em>Terminal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Terminal</em>'.
	 * @see Model.Terminal
	 * @generated
	 */
	EClass getTerminal();

	/**
	 * Returns the meta object for the attribute '{@link Model.Terminal#getSessionName <em>Session Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Session Name</em>'.
	 * @see Model.Terminal#getSessionName()
	 * @see #getTerminal()
	 * @generated
	 */
	EAttribute getTerminal_SessionName();

	/**
	 * Returns the meta object for the '{@link Model.Terminal#Authentication(java.lang.String, java.lang.String) <em>Authentication</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Authentication</em>' operation.
	 * @see Model.Terminal#Authentication(java.lang.String, java.lang.String)
	 * @generated
	 */
	EOperation getTerminal__Authentication__String_String();

	/**
	 * Returns the meta object for the '{@link Model.Terminal#checkAvailability(int, java.lang.String) <em>Check Availability</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Availability</em>' operation.
	 * @see Model.Terminal#checkAvailability(int, java.lang.String)
	 * @generated
	 */
	EOperation getTerminal__CheckAvailability__int_String();

	/**
	 * Returns the meta object for class '{@link Model.Biblioteca <em>Biblioteca</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Biblioteca</em>'.
	 * @see Model.Biblioteca
	 * @generated
	 */
	EClass getBiblioteca();

	/**
	 * Returns the meta object for the attribute '{@link Model.Biblioteca#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see Model.Biblioteca#getName()
	 * @see #getBiblioteca()
	 * @generated
	 */
	EAttribute getBiblioteca_Name();

	/**
	 * Returns the meta object for the attribute '{@link Model.Biblioteca#getAddress <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Address</em>'.
	 * @see Model.Biblioteca#getAddress()
	 * @see #getBiblioteca()
	 * @generated
	 */
	EAttribute getBiblioteca_Address();

	/**
	 * Returns the meta object for the attribute '{@link Model.Biblioteca#getSystemDate <em>System Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>System Date</em>'.
	 * @see Model.Biblioteca#getSystemDate()
	 * @see #getBiblioteca()
	 * @generated
	 */
	EAttribute getBiblioteca_SystemDate();

	/**
	 * Returns the meta object for the '{@link Model.Biblioteca#getSystemDate(java.lang.String) <em>Get System Date</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get System Date</em>' operation.
	 * @see Model.Biblioteca#getSystemDate(java.lang.String)
	 * @generated
	 */
	EOperation getBiblioteca__GetSystemDate__String();

	/**
	 * Returns the meta object for class '{@link Model.Emprestimo <em>Emprestimo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Emprestimo</em>'.
	 * @see Model.Emprestimo
	 * @generated
	 */
	EClass getEmprestimo();

	/**
	 * Returns the meta object for the attribute '{@link Model.Emprestimo#getDevolutionDate <em>Devolution Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Devolution Date</em>'.
	 * @see Model.Emprestimo#getDevolutionDate()
	 * @see #getEmprestimo()
	 * @generated
	 */
	EAttribute getEmprestimo_DevolutionDate();

	/**
	 * Returns the meta object for the attribute '{@link Model.Emprestimo#getBorrowProtocol <em>Borrow Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Borrow Protocol</em>'.
	 * @see Model.Emprestimo#getBorrowProtocol()
	 * @see #getEmprestimo()
	 * @generated
	 */
	EAttribute getEmprestimo_BorrowProtocol();

	/**
	 * Returns the meta object for the '{@link Model.Emprestimo#getDevollutionCharges(int) <em>Get Devollution Charges</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Devollution Charges</em>' operation.
	 * @see Model.Emprestimo#getDevollutionCharges(int)
	 * @generated
	 */
	EOperation getEmprestimo__GetDevollutionCharges__int();

	/**
	 * Returns the meta object for the '{@link Model.Emprestimo#isAvaiable(int) <em>Is Avaiable</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Avaiable</em>' operation.
	 * @see Model.Emprestimo#isAvaiable(int)
	 * @generated
	 */
	EOperation getEmprestimo__IsAvaiable__int();

	/**
	 * Returns the meta object for the '{@link Model.Emprestimo#setDevolutionDate() <em>Set Devolution Date</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Devolution Date</em>' operation.
	 * @see Model.Emprestimo#setDevolutionDate()
	 * @generated
	 */
	EOperation getEmprestimo__SetDevolutionDate();

	/**
	 * Returns the meta object for the '{@link Model.Emprestimo#setBorrowProtocol() <em>Set Borrow Protocol</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Borrow Protocol</em>' operation.
	 * @see Model.Emprestimo#setBorrowProtocol()
	 * @generated
	 */
	EOperation getEmprestimo__SetBorrowProtocol();

	/**
	 * Returns the meta object for the '{@link Model.Emprestimo#cancelReservation(int) <em>Cancel Reservation</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Cancel Reservation</em>' operation.
	 * @see Model.Emprestimo#cancelReservation(int)
	 * @generated
	 */
	EOperation getEmprestimo__CancelReservation__int();

	/**
	 * Returns the meta object for the '{@link Model.Emprestimo#addReservation(int) <em>Add Reservation</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Add Reservation</em>' operation.
	 * @see Model.Emprestimo#addReservation(int)
	 * @generated
	 */
	EOperation getEmprestimo__AddReservation__int();

	/**
	 * Returns the meta object for the '{@link Model.Emprestimo#setCharges() <em>Set Charges</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Charges</em>' operation.
	 * @see Model.Emprestimo#setCharges()
	 * @generated
	 */
	EOperation getEmprestimo__SetCharges();

	/**
	 * Returns the meta object for class '{@link Model.Exemplar <em>Exemplar</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Exemplar</em>'.
	 * @see Model.Exemplar
	 * @generated
	 */
	EClass getExemplar();

	/**
	 * Returns the meta object for the attribute '{@link Model.Exemplar#getAutores <em>Autores</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Autores</em>'.
	 * @see Model.Exemplar#getAutores()
	 * @see #getExemplar()
	 * @generated
	 */
	EAttribute getExemplar_Autores();

	/**
	 * Returns the meta object for the attribute '{@link Model.Exemplar#getTitulo <em>Titulo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Titulo</em>'.
	 * @see Model.Exemplar#getTitulo()
	 * @see #getExemplar()
	 * @generated
	 */
	EAttribute getExemplar_Titulo();

	/**
	 * Returns the meta object for the attribute '{@link Model.Exemplar#isAvailability <em>Availability</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Availability</em>'.
	 * @see Model.Exemplar#isAvailability()
	 * @see #getExemplar()
	 * @generated
	 */
	EAttribute getExemplar_Availability();

	/**
	 * Returns the meta object for the attribute '{@link Model.Exemplar#getLibNumber <em>Lib Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Lib Number</em>'.
	 * @see Model.Exemplar#getLibNumber()
	 * @see #getExemplar()
	 * @generated
	 */
	EAttribute getExemplar_LibNumber();

	/**
	 * Returns the meta object for the attribute '{@link Model.Exemplar#isBlocked <em>Is Blocked</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Blocked</em>'.
	 * @see Model.Exemplar#isBlocked()
	 * @see #getExemplar()
	 * @generated
	 */
	EAttribute getExemplar_IsBlocked();

	/**
	 * Returns the meta object for the '{@link Model.Exemplar#updateCopies(int) <em>Update Copies</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Update Copies</em>' operation.
	 * @see Model.Exemplar#updateCopies(int)
	 * @generated
	 */
	EOperation getExemplar__UpdateCopies__int();

	/**
	 * Returns the meta object for the '{@link Model.Exemplar#block(int) <em>Block</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Block</em>' operation.
	 * @see Model.Exemplar#block(int)
	 * @generated
	 */
	EOperation getExemplar__Block__int();

	/**
	 * Returns the meta object for the '{@link Model.Exemplar#unblock(int) <em>Unblock</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unblock</em>' operation.
	 * @see Model.Exemplar#unblock(int)
	 * @generated
	 */
	EOperation getExemplar__Unblock__int();

	/**
	 * Returns the meta object for class '{@link Model.Publicacao <em>Publicacao</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Publicacao</em>'.
	 * @see Model.Publicacao
	 * @generated
	 */
	EClass getPublicacao();

	/**
	 * Returns the meta object for the attribute '{@link Model.Publicacao#getLibNumber <em>Lib Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Lib Number</em>'.
	 * @see Model.Publicacao#getLibNumber()
	 * @see #getPublicacao()
	 * @generated
	 */
	EAttribute getPublicacao_LibNumber();

	/**
	 * Returns the meta object for the '{@link Model.Publicacao#addNewPublication(int) <em>Add New Publication</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Add New Publication</em>' operation.
	 * @see Model.Publicacao#addNewPublication(int)
	 * @generated
	 */
	EOperation getPublicacao__AddNewPublication__int();

	/**
	 * Returns the meta object for the '{@link Model.Publicacao#removePublication(int) <em>Remove Publication</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Remove Publication</em>' operation.
	 * @see Model.Publicacao#removePublication(int)
	 * @generated
	 */
	EOperation getPublicacao__RemovePublication__int();

	/**
	 * Returns the meta object for the '{@link Model.Publicacao#getLibnumber() <em>Get Libnumber</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Libnumber</em>' operation.
	 * @see Model.Publicacao#getLibnumber()
	 * @generated
	 */
	EOperation getPublicacao__GetLibnumber();

	/**
	 * Returns the meta object for the '{@link Model.Publicacao#setLibnumber() <em>Set Libnumber</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Libnumber</em>' operation.
	 * @see Model.Publicacao#setLibnumber()
	 * @generated
	 */
	EOperation getPublicacao__SetLibnumber();

	/**
	 * Returns the meta object for class '{@link Model.Livro <em>Livro</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Livro</em>'.
	 * @see Model.Livro
	 * @generated
	 */
	EClass getLivro();

	/**
	 * Returns the meta object for the attribute '{@link Model.Livro#getTitulo <em>Titulo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Titulo</em>'.
	 * @see Model.Livro#getTitulo()
	 * @see #getLivro()
	 * @generated
	 */
	EAttribute getLivro_Titulo();

	/**
	 * Returns the meta object for the attribute '{@link Model.Livro#getAutores <em>Autores</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Autores</em>'.
	 * @see Model.Livro#getAutores()
	 * @see #getLivro()
	 * @generated
	 */
	EAttribute getLivro_Autores();

	/**
	 * Returns the meta object for the attribute '{@link Model.Livro#isBorrowed <em>Is Borrowed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Borrowed</em>'.
	 * @see Model.Livro#isBorrowed()
	 * @see #getLivro()
	 * @generated
	 */
	EAttribute getLivro_IsBorrowed();

	/**
	 * Returns the meta object for the '{@link Model.Livro#getInfo(int) <em>Get Info</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Info</em>' operation.
	 * @see Model.Livro#getInfo(int)
	 * @generated
	 */
	EOperation getLivro__GetInfo__int();

	/**
	 * Returns the meta object for the '{@link Model.Livro#setInfo(int) <em>Set Info</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Info</em>' operation.
	 * @see Model.Livro#setInfo(int)
	 * @generated
	 */
	EOperation getLivro__SetInfo__int();

	/**
	 * Returns the meta object for class '{@link Model.Periodico <em>Periodico</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Periodico</em>'.
	 * @see Model.Periodico
	 * @generated
	 */
	EClass getPeriodico();

	/**
	 * Returns the meta object for the attribute '{@link Model.Periodico#getTitulo <em>Titulo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Titulo</em>'.
	 * @see Model.Periodico#getTitulo()
	 * @see #getPeriodico()
	 * @generated
	 */
	EAttribute getPeriodico_Titulo();

	/**
	 * Returns the meta object for the attribute '{@link Model.Periodico#getAutores <em>Autores</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Autores</em>'.
	 * @see Model.Periodico#getAutores()
	 * @see #getPeriodico()
	 * @generated
	 */
	EAttribute getPeriodico_Autores();

	/**
	 * Returns the meta object for the attribute '{@link Model.Periodico#isBorrowed <em>Is Borrowed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Borrowed</em>'.
	 * @see Model.Periodico#isBorrowed()
	 * @see #getPeriodico()
	 * @generated
	 */
	EAttribute getPeriodico_IsBorrowed();

	/**
	 * Returns the meta object for the '{@link Model.Periodico#getInfo(int) <em>Get Info</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Info</em>' operation.
	 * @see Model.Periodico#getInfo(int)
	 * @generated
	 */
	EOperation getPeriodico__GetInfo__int();

	/**
	 * Returns the meta object for the '{@link Model.Periodico#setInfo(int) <em>Set Info</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Info</em>' operation.
	 * @see Model.Periodico#setInfo(int)
	 * @generated
	 */
	EOperation getPeriodico__SetInfo__int();

	/**
	 * Returns the meta object for class '{@link Model.Tese <em>Tese</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tese</em>'.
	 * @see Model.Tese
	 * @generated
	 */
	EClass getTese();

	/**
	 * Returns the meta object for the attribute '{@link Model.Tese#getTitulo <em>Titulo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Titulo</em>'.
	 * @see Model.Tese#getTitulo()
	 * @see #getTese()
	 * @generated
	 */
	EAttribute getTese_Titulo();

	/**
	 * Returns the meta object for the attribute '{@link Model.Tese#isBorrowed <em>Is Borrowed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Borrowed</em>'.
	 * @see Model.Tese#isBorrowed()
	 * @see #getTese()
	 * @generated
	 */
	EAttribute getTese_IsBorrowed();

	/**
	 * Returns the meta object for the attribute '{@link Model.Tese#getAutores <em>Autores</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Autores</em>'.
	 * @see Model.Tese#getAutores()
	 * @see #getTese()
	 * @generated
	 */
	EAttribute getTese_Autores();

	/**
	 * Returns the meta object for the '{@link Model.Tese#getInfo(int) <em>Get Info</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Info</em>' operation.
	 * @see Model.Tese#getInfo(int)
	 * @generated
	 */
	EOperation getTese__GetInfo__int();

	/**
	 * Returns the meta object for the '{@link Model.Tese#setInfo(int) <em>Set Info</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Info</em>' operation.
	 * @see Model.Tese#setInfo(int)
	 * @generated
	 */
	EOperation getTese__SetInfo__int();

	/**
	 * Returns the meta object for class '{@link Model.Manual <em>Manual</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Manual</em>'.
	 * @see Model.Manual
	 * @generated
	 */
	EClass getManual();

	/**
	 * Returns the meta object for the attribute '{@link Model.Manual#getTitulo <em>Titulo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Titulo</em>'.
	 * @see Model.Manual#getTitulo()
	 * @see #getManual()
	 * @generated
	 */
	EAttribute getManual_Titulo();

	/**
	 * Returns the meta object for the attribute '{@link Model.Manual#getAutores <em>Autores</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Autores</em>'.
	 * @see Model.Manual#getAutores()
	 * @see #getManual()
	 * @generated
	 */
	EAttribute getManual_Autores();

	/**
	 * Returns the meta object for the attribute '{@link Model.Manual#isBorrowed <em>Is Borrowed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Borrowed</em>'.
	 * @see Model.Manual#isBorrowed()
	 * @see #getManual()
	 * @generated
	 */
	EAttribute getManual_IsBorrowed();

	/**
	 * Returns the meta object for the '{@link Model.Manual#getInfo(int) <em>Get Info</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Info</em>' operation.
	 * @see Model.Manual#getInfo(int)
	 * @generated
	 */
	EOperation getManual__GetInfo__int();

	/**
	 * Returns the meta object for the '{@link Model.Manual#setInfo(int) <em>Set Info</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Info</em>' operation.
	 * @see Model.Manual#setInfo(int)
	 * @generated
	 */
	EOperation getManual__SetInfo__int();

	/**
	 * Returns the meta object for class '{@link Model.Usuario <em>Usuario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Usuario</em>'.
	 * @see Model.Usuario
	 * @generated
	 */
	EClass getUsuario();

	/**
	 * Returns the meta object for the attribute '{@link Model.Usuario#getCPF <em>CPF</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>CPF</em>'.
	 * @see Model.Usuario#getCPF()
	 * @see #getUsuario()
	 * @generated
	 */
	EAttribute getUsuario_CPF();

	/**
	 * Returns the meta object for the attribute '{@link Model.Usuario#getFirstName <em>First Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>First Name</em>'.
	 * @see Model.Usuario#getFirstName()
	 * @see #getUsuario()
	 * @generated
	 */
	EAttribute getUsuario_FirstName();

	/**
	 * Returns the meta object for the attribute '{@link Model.Usuario#getLastName <em>Last Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Name</em>'.
	 * @see Model.Usuario#getLastName()
	 * @see #getUsuario()
	 * @generated
	 */
	EAttribute getUsuario_LastName();

	/**
	 * Returns the meta object for the attribute '{@link Model.Usuario#getFullName <em>Full Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Full Name</em>'.
	 * @see Model.Usuario#getFullName()
	 * @see #getUsuario()
	 * @generated
	 */
	EAttribute getUsuario_FullName();

	/**
	 * Returns the meta object for the attribute '{@link Model.Usuario#getChargesStatus <em>Charges Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Charges Status</em>'.
	 * @see Model.Usuario#getChargesStatus()
	 * @see #getUsuario()
	 * @generated
	 */
	EAttribute getUsuario_ChargesStatus();

	/**
	 * Returns the meta object for the '{@link Model.Usuario#registerUserAtDataBase(int) <em>Register User At Data Base</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register User At Data Base</em>' operation.
	 * @see Model.Usuario#registerUserAtDataBase(int)
	 * @generated
	 */
	EOperation getUsuario__RegisterUserAtDataBase__int();

	/**
	 * Returns the meta object for the '{@link Model.Usuario#setChargeStatus(int) <em>Set Charge Status</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Charge Status</em>' operation.
	 * @see Model.Usuario#setChargeStatus(int)
	 * @generated
	 */
	EOperation getUsuario__SetChargeStatus__int();

	/**
	 * Returns the meta object for class '{@link Model.Aluno <em>Aluno</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aluno</em>'.
	 * @see Model.Aluno
	 * @generated
	 */
	EClass getAluno();

	/**
	 * Returns the meta object for the attribute '{@link Model.Aluno#getEmail <em>Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Email</em>'.
	 * @see Model.Aluno#getEmail()
	 * @see #getAluno()
	 * @generated
	 */
	EAttribute getAluno_Email();

	/**
	 * Returns the meta object for the attribute '{@link Model.Aluno#getAddress <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Address</em>'.
	 * @see Model.Aluno#getAddress()
	 * @see #getAluno()
	 * @generated
	 */
	EAttribute getAluno_Address();

	/**
	 * Returns the meta object for the attribute '{@link Model.Aluno#getCEP <em>CEP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>CEP</em>'.
	 * @see Model.Aluno#getCEP()
	 * @see #getAluno()
	 * @generated
	 */
	EAttribute getAluno_CEP();

	/**
	 * Returns the meta object for the '{@link Model.Aluno#getFirstName() <em>Get First Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get First Name</em>' operation.
	 * @see Model.Aluno#getFirstName()
	 * @generated
	 */
	EOperation getAluno__GetFirstName();

	/**
	 * Returns the meta object for the '{@link Model.Aluno#setFullName() <em>Set Full Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Full Name</em>' operation.
	 * @see Model.Aluno#setFullName()
	 * @generated
	 */
	EOperation getAluno__SetFullName();

	/**
	 * Returns the meta object for the '{@link Model.Aluno#toRegisterStudent(int) <em>To Register Student</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>To Register Student</em>' operation.
	 * @see Model.Aluno#toRegisterStudent(int)
	 * @generated
	 */
	EOperation getAluno__ToRegisterStudent__int();

	/**
	 * Returns the meta object for the '{@link Model.Aluno#getLastName() <em>Get Last Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Last Name</em>' operation.
	 * @see Model.Aluno#getLastName()
	 * @generated
	 */
	EOperation getAluno__GetLastName();

	/**
	 * Returns the meta object for the '{@link Model.Aluno#setCPF() <em>Set CPF</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set CPF</em>' operation.
	 * @see Model.Aluno#setCPF()
	 * @generated
	 */
	EOperation getAluno__SetCPF();

	/**
	 * Returns the meta object for the '{@link Model.Aluno#setCEP() <em>Set CEP</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set CEP</em>' operation.
	 * @see Model.Aluno#setCEP()
	 * @generated
	 */
	EOperation getAluno__SetCEP();

	/**
	 * Returns the meta object for the '{@link Model.Aluno#CALLForm() <em>CALL Form</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>CALL Form</em>' operation.
	 * @see Model.Aluno#CALLForm()
	 * @generated
	 */
	EOperation getAluno__CALLForm();

	/**
	 * Returns the meta object for the '{@link Model.Aluno#getCep() <em>Get Cep</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Cep</em>' operation.
	 * @see Model.Aluno#getCep()
	 * @generated
	 */
	EOperation getAluno__GetCep();

	/**
	 * Returns the meta object for the '{@link Model.Aluno#getCPF() <em>Get CPF</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get CPF</em>' operation.
	 * @see Model.Aluno#getCPF()
	 * @generated
	 */
	EOperation getAluno__GetCPF();

	/**
	 * Returns the meta object for the '{@link Model.Aluno#setFullAddress() <em>Set Full Address</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Full Address</em>' operation.
	 * @see Model.Aluno#setFullAddress()
	 * @generated
	 */
	EOperation getAluno__SetFullAddress();

	/**
	 * Returns the meta object for class '{@link Model.Professor <em>Professor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Professor</em>'.
	 * @see Model.Professor
	 * @generated
	 */
	EClass getProfessor();

	/**
	 * Returns the meta object for the attribute '{@link Model.Professor#getAddress <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Address</em>'.
	 * @see Model.Professor#getAddress()
	 * @see #getProfessor()
	 * @generated
	 */
	EAttribute getProfessor_Address();

	/**
	 * Returns the meta object for the attribute '{@link Model.Professor#getEmail <em>Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Email</em>'.
	 * @see Model.Professor#getEmail()
	 * @see #getProfessor()
	 * @generated
	 */
	EAttribute getProfessor_Email();

	/**
	 * Returns the meta object for the attribute '{@link Model.Professor#getCEP <em>CEP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>CEP</em>'.
	 * @see Model.Professor#getCEP()
	 * @see #getProfessor()
	 * @generated
	 */
	EAttribute getProfessor_CEP();

	/**
	 * Returns the meta object for the '{@link Model.Professor#setCEP() <em>Set CEP</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set CEP</em>' operation.
	 * @see Model.Professor#setCEP()
	 * @generated
	 */
	EOperation getProfessor__SetCEP();

	/**
	 * Returns the meta object for the '{@link Model.Professor#getLastName() <em>Get Last Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Last Name</em>' operation.
	 * @see Model.Professor#getLastName()
	 * @generated
	 */
	EOperation getProfessor__GetLastName();

	/**
	 * Returns the meta object for the '{@link Model.Professor#getFirstName() <em>Get First Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get First Name</em>' operation.
	 * @see Model.Professor#getFirstName()
	 * @generated
	 */
	EOperation getProfessor__GetFirstName();

	/**
	 * Returns the meta object for the '{@link Model.Professor#setFullName() <em>Set Full Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Full Name</em>' operation.
	 * @see Model.Professor#setFullName()
	 * @generated
	 */
	EOperation getProfessor__SetFullName();

	/**
	 * Returns the meta object for the '{@link Model.Professor#toRegisterProfessor(int) <em>To Register Professor</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>To Register Professor</em>' operation.
	 * @see Model.Professor#toRegisterProfessor(int)
	 * @generated
	 */
	EOperation getProfessor__ToRegisterProfessor__int();

	/**
	 * Returns the meta object for the '{@link Model.Professor#setCPF() <em>Set CPF</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set CPF</em>' operation.
	 * @see Model.Professor#setCPF()
	 * @generated
	 */
	EOperation getProfessor__SetCPF();

	/**
	 * Returns the meta object for the '{@link Model.Professor#CALLForm() <em>CALL Form</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>CALL Form</em>' operation.
	 * @see Model.Professor#CALLForm()
	 * @generated
	 */
	EOperation getProfessor__CALLForm();

	/**
	 * Returns the meta object for the '{@link Model.Professor#getCep() <em>Get Cep</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Cep</em>' operation.
	 * @see Model.Professor#getCep()
	 * @generated
	 */
	EOperation getProfessor__GetCep();

	/**
	 * Returns the meta object for the '{@link Model.Professor#getCPF() <em>Get CPF</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get CPF</em>' operation.
	 * @see Model.Professor#getCPF()
	 * @generated
	 */
	EOperation getProfessor__GetCPF();

	/**
	 * Returns the meta object for the '{@link Model.Professor#setFullAddress() <em>Set Full Address</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Full Address</em>' operation.
	 * @see Model.Professor#setFullAddress()
	 * @generated
	 */
	EOperation getProfessor__SetFullAddress();

	/**
	 * Returns the meta object for class '{@link Model.Funcionario <em>Funcionario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Funcionario</em>'.
	 * @see Model.Funcionario
	 * @generated
	 */
	EClass getFuncionario();

	/**
	 * Returns the meta object for the attribute '{@link Model.Funcionario#getCEP <em>CEP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>CEP</em>'.
	 * @see Model.Funcionario#getCEP()
	 * @see #getFuncionario()
	 * @generated
	 */
	EAttribute getFuncionario_CEP();

	/**
	 * Returns the meta object for the attribute '{@link Model.Funcionario#getEmail <em>Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Email</em>'.
	 * @see Model.Funcionario#getEmail()
	 * @see #getFuncionario()
	 * @generated
	 */
	EAttribute getFuncionario_Email();

	/**
	 * Returns the meta object for the attribute '{@link Model.Funcionario#getAddress <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Address</em>'.
	 * @see Model.Funcionario#getAddress()
	 * @see #getFuncionario()
	 * @generated
	 */
	EAttribute getFuncionario_Address();

	/**
	 * Returns the meta object for the '{@link Model.Funcionario#setFullName() <em>Set Full Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Full Name</em>' operation.
	 * @see Model.Funcionario#setFullName()
	 * @generated
	 */
	EOperation getFuncionario__SetFullName();

	/**
	 * Returns the meta object for the '{@link Model.Funcionario#setCEP() <em>Set CEP</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set CEP</em>' operation.
	 * @see Model.Funcionario#setCEP()
	 * @generated
	 */
	EOperation getFuncionario__SetCEP();

	/**
	 * Returns the meta object for the '{@link Model.Funcionario#setCPF() <em>Set CPF</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set CPF</em>' operation.
	 * @see Model.Funcionario#setCPF()
	 * @generated
	 */
	EOperation getFuncionario__SetCPF();

	/**
	 * Returns the meta object for the '{@link Model.Funcionario#toRegisterEmployee(int) <em>To Register Employee</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>To Register Employee</em>' operation.
	 * @see Model.Funcionario#toRegisterEmployee(int)
	 * @generated
	 */
	EOperation getFuncionario__ToRegisterEmployee__int();

	/**
	 * Returns the meta object for the '{@link Model.Funcionario#getFirstName() <em>Get First Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get First Name</em>' operation.
	 * @see Model.Funcionario#getFirstName()
	 * @generated
	 */
	EOperation getFuncionario__GetFirstName();

	/**
	 * Returns the meta object for the '{@link Model.Funcionario#getLastName() <em>Get Last Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Last Name</em>' operation.
	 * @see Model.Funcionario#getLastName()
	 * @generated
	 */
	EOperation getFuncionario__GetLastName();

	/**
	 * Returns the meta object for the '{@link Model.Funcionario#CALLForm() <em>CALL Form</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>CALL Form</em>' operation.
	 * @see Model.Funcionario#CALLForm()
	 * @generated
	 */
	EOperation getFuncionario__CALLForm();

	/**
	 * Returns the meta object for the '{@link Model.Funcionario#getCep() <em>Get Cep</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Cep</em>' operation.
	 * @see Model.Funcionario#getCep()
	 * @generated
	 */
	EOperation getFuncionario__GetCep();

	/**
	 * Returns the meta object for the '{@link Model.Funcionario#setFullAddress() <em>Set Full Address</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Full Address</em>' operation.
	 * @see Model.Funcionario#setFullAddress()
	 * @generated
	 */
	EOperation getFuncionario__SetFullAddress();

	/**
	 * Returns the meta object for the '{@link Model.Funcionario#getCPF() <em>Get CPF</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get CPF</em>' operation.
	 * @see Model.Funcionario#getCPF()
	 * @generated
	 */
	EOperation getFuncionario__GetCPF();

	/**
	 * Returns the meta object for class '{@link Model.DeptoA <em>Depto A</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Depto A</em>'.
	 * @see Model.DeptoA
	 * @generated
	 */
	EClass getDeptoA();

	/**
	 * Returns the meta object for the attribute '{@link Model.DeptoA#getDeptName <em>Dept Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dept Name</em>'.
	 * @see Model.DeptoA#getDeptName()
	 * @see #getDeptoA()
	 * @generated
	 */
	EAttribute getDeptoA_DeptName();

	/**
	 * Returns the meta object for the '{@link Model.DeptoA#getDeptname() <em>Get Deptname</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Deptname</em>' operation.
	 * @see Model.DeptoA#getDeptname()
	 * @generated
	 */
	EOperation getDeptoA__GetDeptname();

	/**
	 * Returns the meta object for the '{@link Model.DeptoA#setDeptName() <em>Set Dept Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Dept Name</em>' operation.
	 * @see Model.DeptoA#setDeptName()
	 * @generated
	 */
	EOperation getDeptoA__SetDeptName();

	/**
	 * Returns the meta object for class '{@link Model.Departamentos <em>Departamentos</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Departamentos</em>'.
	 * @see Model.Departamentos
	 * @generated
	 */
	EClass getDepartamentos();

	/**
	 * Returns the meta object for class '{@link Model.DeptoB <em>Depto B</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Depto B</em>'.
	 * @see Model.DeptoB
	 * @generated
	 */
	EClass getDeptoB();

	/**
	 * Returns the meta object for the attribute '{@link Model.DeptoB#getDeptName <em>Dept Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dept Name</em>'.
	 * @see Model.DeptoB#getDeptName()
	 * @see #getDeptoB()
	 * @generated
	 */
	EAttribute getDeptoB_DeptName();

	/**
	 * Returns the meta object for the '{@link Model.DeptoB#getDeptname() <em>Get Deptname</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Deptname</em>' operation.
	 * @see Model.DeptoB#getDeptname()
	 * @generated
	 */
	EOperation getDeptoB__GetDeptname();

	/**
	 * Returns the meta object for the '{@link Model.DeptoB#setDeptName() <em>Set Dept Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Dept Name</em>' operation.
	 * @see Model.DeptoB#setDeptName()
	 * @generated
	 */
	EOperation getDeptoB__SetDeptName();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ModelFactory getModelFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link Model.impl.TerminalImpl <em>Terminal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.TerminalImpl
		 * @see Model.impl.ModelPackageImpl#getTerminal()
		 * @generated
		 */
		EClass TERMINAL = eINSTANCE.getTerminal();

		/**
		 * The meta object literal for the '<em><b>Session Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TERMINAL__SESSION_NAME = eINSTANCE.getTerminal_SessionName();

		/**
		 * The meta object literal for the '<em><b>Authentication</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TERMINAL___AUTHENTICATION__STRING_STRING = eINSTANCE.getTerminal__Authentication__String_String();

		/**
		 * The meta object literal for the '<em><b>Check Availability</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TERMINAL___CHECK_AVAILABILITY__INT_STRING = eINSTANCE.getTerminal__CheckAvailability__int_String();

		/**
		 * The meta object literal for the '{@link Model.impl.BibliotecaImpl <em>Biblioteca</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.BibliotecaImpl
		 * @see Model.impl.ModelPackageImpl#getBiblioteca()
		 * @generated
		 */
		EClass BIBLIOTECA = eINSTANCE.getBiblioteca();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BIBLIOTECA__NAME = eINSTANCE.getBiblioteca_Name();

		/**
		 * The meta object literal for the '<em><b>Address</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BIBLIOTECA__ADDRESS = eINSTANCE.getBiblioteca_Address();

		/**
		 * The meta object literal for the '<em><b>System Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BIBLIOTECA__SYSTEM_DATE = eINSTANCE.getBiblioteca_SystemDate();

		/**
		 * The meta object literal for the '<em><b>Get System Date</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation BIBLIOTECA___GET_SYSTEM_DATE__STRING = eINSTANCE.getBiblioteca__GetSystemDate__String();

		/**
		 * The meta object literal for the '{@link Model.impl.EmprestimoImpl <em>Emprestimo</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.EmprestimoImpl
		 * @see Model.impl.ModelPackageImpl#getEmprestimo()
		 * @generated
		 */
		EClass EMPRESTIMO = eINSTANCE.getEmprestimo();

		/**
		 * The meta object literal for the '<em><b>Devolution Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EMPRESTIMO__DEVOLUTION_DATE = eINSTANCE.getEmprestimo_DevolutionDate();

		/**
		 * The meta object literal for the '<em><b>Borrow Protocol</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EMPRESTIMO__BORROW_PROTOCOL = eINSTANCE.getEmprestimo_BorrowProtocol();

		/**
		 * The meta object literal for the '<em><b>Get Devollution Charges</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation EMPRESTIMO___GET_DEVOLLUTION_CHARGES__INT = eINSTANCE.getEmprestimo__GetDevollutionCharges__int();

		/**
		 * The meta object literal for the '<em><b>Is Avaiable</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation EMPRESTIMO___IS_AVAIABLE__INT = eINSTANCE.getEmprestimo__IsAvaiable__int();

		/**
		 * The meta object literal for the '<em><b>Set Devolution Date</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation EMPRESTIMO___SET_DEVOLUTION_DATE = eINSTANCE.getEmprestimo__SetDevolutionDate();

		/**
		 * The meta object literal for the '<em><b>Set Borrow Protocol</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation EMPRESTIMO___SET_BORROW_PROTOCOL = eINSTANCE.getEmprestimo__SetBorrowProtocol();

		/**
		 * The meta object literal for the '<em><b>Cancel Reservation</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation EMPRESTIMO___CANCEL_RESERVATION__INT = eINSTANCE.getEmprestimo__CancelReservation__int();

		/**
		 * The meta object literal for the '<em><b>Add Reservation</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation EMPRESTIMO___ADD_RESERVATION__INT = eINSTANCE.getEmprestimo__AddReservation__int();

		/**
		 * The meta object literal for the '<em><b>Set Charges</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation EMPRESTIMO___SET_CHARGES = eINSTANCE.getEmprestimo__SetCharges();

		/**
		 * The meta object literal for the '{@link Model.impl.ExemplarImpl <em>Exemplar</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.ExemplarImpl
		 * @see Model.impl.ModelPackageImpl#getExemplar()
		 * @generated
		 */
		EClass EXEMPLAR = eINSTANCE.getExemplar();

		/**
		 * The meta object literal for the '<em><b>Autores</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXEMPLAR__AUTORES = eINSTANCE.getExemplar_Autores();

		/**
		 * The meta object literal for the '<em><b>Titulo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXEMPLAR__TITULO = eINSTANCE.getExemplar_Titulo();

		/**
		 * The meta object literal for the '<em><b>Availability</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXEMPLAR__AVAILABILITY = eINSTANCE.getExemplar_Availability();

		/**
		 * The meta object literal for the '<em><b>Lib Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXEMPLAR__LIB_NUMBER = eINSTANCE.getExemplar_LibNumber();

		/**
		 * The meta object literal for the '<em><b>Is Blocked</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXEMPLAR__IS_BLOCKED = eINSTANCE.getExemplar_IsBlocked();

		/**
		 * The meta object literal for the '<em><b>Update Copies</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation EXEMPLAR___UPDATE_COPIES__INT = eINSTANCE.getExemplar__UpdateCopies__int();

		/**
		 * The meta object literal for the '<em><b>Block</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation EXEMPLAR___BLOCK__INT = eINSTANCE.getExemplar__Block__int();

		/**
		 * The meta object literal for the '<em><b>Unblock</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation EXEMPLAR___UNBLOCK__INT = eINSTANCE.getExemplar__Unblock__int();

		/**
		 * The meta object literal for the '{@link Model.impl.PublicacaoImpl <em>Publicacao</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.PublicacaoImpl
		 * @see Model.impl.ModelPackageImpl#getPublicacao()
		 * @generated
		 */
		EClass PUBLICACAO = eINSTANCE.getPublicacao();

		/**
		 * The meta object literal for the '<em><b>Lib Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PUBLICACAO__LIB_NUMBER = eINSTANCE.getPublicacao_LibNumber();

		/**
		 * The meta object literal for the '<em><b>Add New Publication</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PUBLICACAO___ADD_NEW_PUBLICATION__INT = eINSTANCE.getPublicacao__AddNewPublication__int();

		/**
		 * The meta object literal for the '<em><b>Remove Publication</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PUBLICACAO___REMOVE_PUBLICATION__INT = eINSTANCE.getPublicacao__RemovePublication__int();

		/**
		 * The meta object literal for the '<em><b>Get Libnumber</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PUBLICACAO___GET_LIBNUMBER = eINSTANCE.getPublicacao__GetLibnumber();

		/**
		 * The meta object literal for the '<em><b>Set Libnumber</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PUBLICACAO___SET_LIBNUMBER = eINSTANCE.getPublicacao__SetLibnumber();

		/**
		 * The meta object literal for the '{@link Model.impl.LivroImpl <em>Livro</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.LivroImpl
		 * @see Model.impl.ModelPackageImpl#getLivro()
		 * @generated
		 */
		EClass LIVRO = eINSTANCE.getLivro();

		/**
		 * The meta object literal for the '<em><b>Titulo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIVRO__TITULO = eINSTANCE.getLivro_Titulo();

		/**
		 * The meta object literal for the '<em><b>Autores</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIVRO__AUTORES = eINSTANCE.getLivro_Autores();

		/**
		 * The meta object literal for the '<em><b>Is Borrowed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIVRO__IS_BORROWED = eINSTANCE.getLivro_IsBorrowed();

		/**
		 * The meta object literal for the '<em><b>Get Info</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LIVRO___GET_INFO__INT = eINSTANCE.getLivro__GetInfo__int();

		/**
		 * The meta object literal for the '<em><b>Set Info</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LIVRO___SET_INFO__INT = eINSTANCE.getLivro__SetInfo__int();

		/**
		 * The meta object literal for the '{@link Model.impl.PeriodicoImpl <em>Periodico</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.PeriodicoImpl
		 * @see Model.impl.ModelPackageImpl#getPeriodico()
		 * @generated
		 */
		EClass PERIODICO = eINSTANCE.getPeriodico();

		/**
		 * The meta object literal for the '<em><b>Titulo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERIODICO__TITULO = eINSTANCE.getPeriodico_Titulo();

		/**
		 * The meta object literal for the '<em><b>Autores</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERIODICO__AUTORES = eINSTANCE.getPeriodico_Autores();

		/**
		 * The meta object literal for the '<em><b>Is Borrowed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERIODICO__IS_BORROWED = eINSTANCE.getPeriodico_IsBorrowed();

		/**
		 * The meta object literal for the '<em><b>Get Info</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERIODICO___GET_INFO__INT = eINSTANCE.getPeriodico__GetInfo__int();

		/**
		 * The meta object literal for the '<em><b>Set Info</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERIODICO___SET_INFO__INT = eINSTANCE.getPeriodico__SetInfo__int();

		/**
		 * The meta object literal for the '{@link Model.impl.TeseImpl <em>Tese</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.TeseImpl
		 * @see Model.impl.ModelPackageImpl#getTese()
		 * @generated
		 */
		EClass TESE = eINSTANCE.getTese();

		/**
		 * The meta object literal for the '<em><b>Titulo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TESE__TITULO = eINSTANCE.getTese_Titulo();

		/**
		 * The meta object literal for the '<em><b>Is Borrowed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TESE__IS_BORROWED = eINSTANCE.getTese_IsBorrowed();

		/**
		 * The meta object literal for the '<em><b>Autores</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TESE__AUTORES = eINSTANCE.getTese_Autores();

		/**
		 * The meta object literal for the '<em><b>Get Info</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TESE___GET_INFO__INT = eINSTANCE.getTese__GetInfo__int();

		/**
		 * The meta object literal for the '<em><b>Set Info</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TESE___SET_INFO__INT = eINSTANCE.getTese__SetInfo__int();

		/**
		 * The meta object literal for the '{@link Model.impl.ManualImpl <em>Manual</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.ManualImpl
		 * @see Model.impl.ModelPackageImpl#getManual()
		 * @generated
		 */
		EClass MANUAL = eINSTANCE.getManual();

		/**
		 * The meta object literal for the '<em><b>Titulo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MANUAL__TITULO = eINSTANCE.getManual_Titulo();

		/**
		 * The meta object literal for the '<em><b>Autores</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MANUAL__AUTORES = eINSTANCE.getManual_Autores();

		/**
		 * The meta object literal for the '<em><b>Is Borrowed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MANUAL__IS_BORROWED = eINSTANCE.getManual_IsBorrowed();

		/**
		 * The meta object literal for the '<em><b>Get Info</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation MANUAL___GET_INFO__INT = eINSTANCE.getManual__GetInfo__int();

		/**
		 * The meta object literal for the '<em><b>Set Info</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation MANUAL___SET_INFO__INT = eINSTANCE.getManual__SetInfo__int();

		/**
		 * The meta object literal for the '{@link Model.impl.UsuarioImpl <em>Usuario</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.UsuarioImpl
		 * @see Model.impl.ModelPackageImpl#getUsuario()
		 * @generated
		 */
		EClass USUARIO = eINSTANCE.getUsuario();

		/**
		 * The meta object literal for the '<em><b>CPF</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USUARIO__CPF = eINSTANCE.getUsuario_CPF();

		/**
		 * The meta object literal for the '<em><b>First Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USUARIO__FIRST_NAME = eINSTANCE.getUsuario_FirstName();

		/**
		 * The meta object literal for the '<em><b>Last Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USUARIO__LAST_NAME = eINSTANCE.getUsuario_LastName();

		/**
		 * The meta object literal for the '<em><b>Full Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USUARIO__FULL_NAME = eINSTANCE.getUsuario_FullName();

		/**
		 * The meta object literal for the '<em><b>Charges Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USUARIO__CHARGES_STATUS = eINSTANCE.getUsuario_ChargesStatus();

		/**
		 * The meta object literal for the '<em><b>Register User At Data Base</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation USUARIO___REGISTER_USER_AT_DATA_BASE__INT = eINSTANCE.getUsuario__RegisterUserAtDataBase__int();

		/**
		 * The meta object literal for the '<em><b>Set Charge Status</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation USUARIO___SET_CHARGE_STATUS__INT = eINSTANCE.getUsuario__SetChargeStatus__int();

		/**
		 * The meta object literal for the '{@link Model.impl.AlunoImpl <em>Aluno</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.AlunoImpl
		 * @see Model.impl.ModelPackageImpl#getAluno()
		 * @generated
		 */
		EClass ALUNO = eINSTANCE.getAluno();

		/**
		 * The meta object literal for the '<em><b>Email</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALUNO__EMAIL = eINSTANCE.getAluno_Email();

		/**
		 * The meta object literal for the '<em><b>Address</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALUNO__ADDRESS = eINSTANCE.getAluno_Address();

		/**
		 * The meta object literal for the '<em><b>CEP</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALUNO__CEP = eINSTANCE.getAluno_CEP();

		/**
		 * The meta object literal for the '<em><b>Get First Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ALUNO___GET_FIRST_NAME = eINSTANCE.getAluno__GetFirstName();

		/**
		 * The meta object literal for the '<em><b>Set Full Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ALUNO___SET_FULL_NAME = eINSTANCE.getAluno__SetFullName();

		/**
		 * The meta object literal for the '<em><b>To Register Student</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ALUNO___TO_REGISTER_STUDENT__INT = eINSTANCE.getAluno__ToRegisterStudent__int();

		/**
		 * The meta object literal for the '<em><b>Get Last Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ALUNO___GET_LAST_NAME = eINSTANCE.getAluno__GetLastName();

		/**
		 * The meta object literal for the '<em><b>Set CPF</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ALUNO___SET_CPF = eINSTANCE.getAluno__SetCPF();

		/**
		 * The meta object literal for the '<em><b>Set CEP</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ALUNO___SET_CEP = eINSTANCE.getAluno__SetCEP();

		/**
		 * The meta object literal for the '<em><b>CALL Form</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ALUNO___CALL_FORM = eINSTANCE.getAluno__CALLForm();

		/**
		 * The meta object literal for the '<em><b>Get Cep</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ALUNO___GET_CEP = eINSTANCE.getAluno__GetCep();

		/**
		 * The meta object literal for the '<em><b>Get CPF</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ALUNO___GET_CPF = eINSTANCE.getAluno__GetCPF();

		/**
		 * The meta object literal for the '<em><b>Set Full Address</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ALUNO___SET_FULL_ADDRESS = eINSTANCE.getAluno__SetFullAddress();

		/**
		 * The meta object literal for the '{@link Model.impl.ProfessorImpl <em>Professor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.ProfessorImpl
		 * @see Model.impl.ModelPackageImpl#getProfessor()
		 * @generated
		 */
		EClass PROFESSOR = eINSTANCE.getProfessor();

		/**
		 * The meta object literal for the '<em><b>Address</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROFESSOR__ADDRESS = eINSTANCE.getProfessor_Address();

		/**
		 * The meta object literal for the '<em><b>Email</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROFESSOR__EMAIL = eINSTANCE.getProfessor_Email();

		/**
		 * The meta object literal for the '<em><b>CEP</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROFESSOR__CEP = eINSTANCE.getProfessor_CEP();

		/**
		 * The meta object literal for the '<em><b>Set CEP</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PROFESSOR___SET_CEP = eINSTANCE.getProfessor__SetCEP();

		/**
		 * The meta object literal for the '<em><b>Get Last Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PROFESSOR___GET_LAST_NAME = eINSTANCE.getProfessor__GetLastName();

		/**
		 * The meta object literal for the '<em><b>Get First Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PROFESSOR___GET_FIRST_NAME = eINSTANCE.getProfessor__GetFirstName();

		/**
		 * The meta object literal for the '<em><b>Set Full Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PROFESSOR___SET_FULL_NAME = eINSTANCE.getProfessor__SetFullName();

		/**
		 * The meta object literal for the '<em><b>To Register Professor</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PROFESSOR___TO_REGISTER_PROFESSOR__INT = eINSTANCE.getProfessor__ToRegisterProfessor__int();

		/**
		 * The meta object literal for the '<em><b>Set CPF</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PROFESSOR___SET_CPF = eINSTANCE.getProfessor__SetCPF();

		/**
		 * The meta object literal for the '<em><b>CALL Form</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PROFESSOR___CALL_FORM = eINSTANCE.getProfessor__CALLForm();

		/**
		 * The meta object literal for the '<em><b>Get Cep</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PROFESSOR___GET_CEP = eINSTANCE.getProfessor__GetCep();

		/**
		 * The meta object literal for the '<em><b>Get CPF</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PROFESSOR___GET_CPF = eINSTANCE.getProfessor__GetCPF();

		/**
		 * The meta object literal for the '<em><b>Set Full Address</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PROFESSOR___SET_FULL_ADDRESS = eINSTANCE.getProfessor__SetFullAddress();

		/**
		 * The meta object literal for the '{@link Model.impl.FuncionarioImpl <em>Funcionario</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.FuncionarioImpl
		 * @see Model.impl.ModelPackageImpl#getFuncionario()
		 * @generated
		 */
		EClass FUNCIONARIO = eINSTANCE.getFuncionario();

		/**
		 * The meta object literal for the '<em><b>CEP</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FUNCIONARIO__CEP = eINSTANCE.getFuncionario_CEP();

		/**
		 * The meta object literal for the '<em><b>Email</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FUNCIONARIO__EMAIL = eINSTANCE.getFuncionario_Email();

		/**
		 * The meta object literal for the '<em><b>Address</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FUNCIONARIO__ADDRESS = eINSTANCE.getFuncionario_Address();

		/**
		 * The meta object literal for the '<em><b>Set Full Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FUNCIONARIO___SET_FULL_NAME = eINSTANCE.getFuncionario__SetFullName();

		/**
		 * The meta object literal for the '<em><b>Set CEP</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FUNCIONARIO___SET_CEP = eINSTANCE.getFuncionario__SetCEP();

		/**
		 * The meta object literal for the '<em><b>Set CPF</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FUNCIONARIO___SET_CPF = eINSTANCE.getFuncionario__SetCPF();

		/**
		 * The meta object literal for the '<em><b>To Register Employee</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FUNCIONARIO___TO_REGISTER_EMPLOYEE__INT = eINSTANCE.getFuncionario__ToRegisterEmployee__int();

		/**
		 * The meta object literal for the '<em><b>Get First Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FUNCIONARIO___GET_FIRST_NAME = eINSTANCE.getFuncionario__GetFirstName();

		/**
		 * The meta object literal for the '<em><b>Get Last Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FUNCIONARIO___GET_LAST_NAME = eINSTANCE.getFuncionario__GetLastName();

		/**
		 * The meta object literal for the '<em><b>CALL Form</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FUNCIONARIO___CALL_FORM = eINSTANCE.getFuncionario__CALLForm();

		/**
		 * The meta object literal for the '<em><b>Get Cep</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FUNCIONARIO___GET_CEP = eINSTANCE.getFuncionario__GetCep();

		/**
		 * The meta object literal for the '<em><b>Set Full Address</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FUNCIONARIO___SET_FULL_ADDRESS = eINSTANCE.getFuncionario__SetFullAddress();

		/**
		 * The meta object literal for the '<em><b>Get CPF</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FUNCIONARIO___GET_CPF = eINSTANCE.getFuncionario__GetCPF();

		/**
		 * The meta object literal for the '{@link Model.impl.DeptoAImpl <em>Depto A</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.DeptoAImpl
		 * @see Model.impl.ModelPackageImpl#getDeptoA()
		 * @generated
		 */
		EClass DEPTO_A = eINSTANCE.getDeptoA();

		/**
		 * The meta object literal for the '<em><b>Dept Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPTO_A__DEPT_NAME = eINSTANCE.getDeptoA_DeptName();

		/**
		 * The meta object literal for the '<em><b>Get Deptname</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DEPTO_A___GET_DEPTNAME = eINSTANCE.getDeptoA__GetDeptname();

		/**
		 * The meta object literal for the '<em><b>Set Dept Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DEPTO_A___SET_DEPT_NAME = eINSTANCE.getDeptoA__SetDeptName();

		/**
		 * The meta object literal for the '{@link Model.impl.DepartamentosImpl <em>Departamentos</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.DepartamentosImpl
		 * @see Model.impl.ModelPackageImpl#getDepartamentos()
		 * @generated
		 */
		EClass DEPARTAMENTOS = eINSTANCE.getDepartamentos();

		/**
		 * The meta object literal for the '{@link Model.impl.DeptoBImpl <em>Depto B</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Model.impl.DeptoBImpl
		 * @see Model.impl.ModelPackageImpl#getDeptoB()
		 * @generated
		 */
		EClass DEPTO_B = eINSTANCE.getDeptoB();

		/**
		 * The meta object literal for the '<em><b>Dept Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPTO_B__DEPT_NAME = eINSTANCE.getDeptoB_DeptName();

		/**
		 * The meta object literal for the '<em><b>Get Deptname</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DEPTO_B___GET_DEPTNAME = eINSTANCE.getDeptoB__GetDeptname();

		/**
		 * The meta object literal for the '<em><b>Set Dept Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DEPTO_B___SET_DEPT_NAME = eINSTANCE.getDeptoB__SetDeptName();

	}

} //ModelPackage
