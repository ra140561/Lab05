/**
 */
package Model;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Exemplar</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Model.Exemplar#getAutores <em>Autores</em>}</li>
 *   <li>{@link Model.Exemplar#getTitulo <em>Titulo</em>}</li>
 *   <li>{@link Model.Exemplar#isAvailability <em>Availability</em>}</li>
 *   <li>{@link Model.Exemplar#getLibNumber <em>Lib Number</em>}</li>
 *   <li>{@link Model.Exemplar#isBlocked <em>Is Blocked</em>}</li>
 * </ul>
 * </p>
 *
 * @see Model.ModelPackage#getExemplar()
 * @model
 * @generated
 */
public interface Exemplar extends EObject {
	/**
	 * Returns the value of the '<em><b>Autores</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Autores</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Autores</em>' attribute.
	 * @see #setAutores(String)
	 * @see Model.ModelPackage#getExemplar_Autores()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getAutores();

	/**
	 * Sets the value of the '{@link Model.Exemplar#getAutores <em>Autores</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Autores</em>' attribute.
	 * @see #getAutores()
	 * @generated
	 */
	void setAutores(String value);

	/**
	 * Returns the value of the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Titulo</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Titulo</em>' attribute.
	 * @see #setTitulo(String)
	 * @see Model.ModelPackage#getExemplar_Titulo()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getTitulo();

	/**
	 * Sets the value of the '{@link Model.Exemplar#getTitulo <em>Titulo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Titulo</em>' attribute.
	 * @see #getTitulo()
	 * @generated
	 */
	void setTitulo(String value);

	/**
	 * Returns the value of the '<em><b>Availability</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Availability</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Availability</em>' attribute.
	 * @see #setAvailability(boolean)
	 * @see Model.ModelPackage#getExemplar_Availability()
	 * @model dataType="org.eclipse.uml2.types.Boolean" required="true" ordered="false"
	 * @generated
	 */
	boolean isAvailability();

	/**
	 * Sets the value of the '{@link Model.Exemplar#isAvailability <em>Availability</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Availability</em>' attribute.
	 * @see #isAvailability()
	 * @generated
	 */
	void setAvailability(boolean value);

	/**
	 * Returns the value of the '<em><b>Lib Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lib Number</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lib Number</em>' attribute.
	 * @see #setLibNumber(int)
	 * @see Model.ModelPackage#getExemplar_LibNumber()
	 * @model dataType="org.eclipse.uml2.types.Integer" required="true" ordered="false"
	 * @generated
	 */
	int getLibNumber();

	/**
	 * Sets the value of the '{@link Model.Exemplar#getLibNumber <em>Lib Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lib Number</em>' attribute.
	 * @see #getLibNumber()
	 * @generated
	 */
	void setLibNumber(int value);

	/**
	 * Returns the value of the '<em><b>Is Blocked</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Blocked</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Blocked</em>' attribute.
	 * @see #setIsBlocked(boolean)
	 * @see Model.ModelPackage#getExemplar_IsBlocked()
	 * @model dataType="org.eclipse.uml2.types.Boolean" required="true" ordered="false"
	 * @generated
	 */
	boolean isBlocked();

	/**
	 * Sets the value of the '{@link Model.Exemplar#isBlocked <em>Is Blocked</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Blocked</em>' attribute.
	 * @see #isBlocked()
	 * @generated
	 */
	void setIsBlocked(boolean value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model LibNumDataType="org.eclipse.uml2.types.Integer" LibNumRequired="true" LibNumOrdered="false"
	 * @generated
	 */
	void updateCopies(int LibNum);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model LibNumDataType="org.eclipse.uml2.types.Integer" LibNumRequired="true" LibNumOrdered="false"
	 * @generated
	 */
	void block(int LibNum);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model LibNumDataType="org.eclipse.uml2.types.Integer" LibNumRequired="true" LibNumOrdered="false"
	 * @generated
	 */
	void unblock(int LibNum);

} // Exemplar
