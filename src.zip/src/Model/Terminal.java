/**
 */
package Model;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Terminal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Model.Terminal#getSessionName <em>Session Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see Model.ModelPackage#getTerminal()
 * @model
 * @generated
 */
public interface Terminal extends EObject {
	/**
	 * Returns the value of the '<em><b>Session Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Session Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Session Name</em>' attribute.
	 * @see #setSessionName(int)
	 * @see Model.ModelPackage#getTerminal_SessionName()
	 * @model dataType="org.eclipse.uml2.types.Integer" required="true" ordered="false"
	 * @generated
	 */
	int getSessionName();

	/**
	 * Sets the value of the '{@link Model.Terminal#getSessionName <em>Session Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Session Name</em>' attribute.
	 * @see #getSessionName()
	 * @generated
	 */
	void setSessionName(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="org.eclipse.uml2.types.Integer" required="true" ordered="false" UsernameDataType="org.eclipse.uml2.types.String" UsernameRequired="true" UsernameOrdered="false" PassDataType="org.eclipse.uml2.types.String" PassRequired="true" PassOrdered="false"
	 * @generated
	 */
	int Authentication(String Username, String Pass);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="org.eclipse.uml2.types.Boolean" required="true" ordered="false" LibNumDataType="org.eclipse.uml2.types.Integer" LibNumRequired="true" LibNumOrdered="false" PubNameDataType="org.eclipse.uml2.types.String" PubNameRequired="true" PubNameOrdered="false"
	 * @generated
	 */
	boolean checkAvailability(int LibNum, String PubName);

} // Terminal
