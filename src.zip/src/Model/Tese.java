/**
 */
package Model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tese</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Model.Tese#getTitulo <em>Titulo</em>}</li>
 *   <li>{@link Model.Tese#isBorrowed <em>Is Borrowed</em>}</li>
 *   <li>{@link Model.Tese#getAutores <em>Autores</em>}</li>
 * </ul>
 * </p>
 *
 * @see Model.ModelPackage#getTese()
 * @model
 * @generated
 */
public interface Tese extends Publicacao {
	/**
	 * Returns the value of the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Titulo</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Titulo</em>' attribute.
	 * @see #setTitulo(String)
	 * @see Model.ModelPackage#getTese_Titulo()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getTitulo();

	/**
	 * Sets the value of the '{@link Model.Tese#getTitulo <em>Titulo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Titulo</em>' attribute.
	 * @see #getTitulo()
	 * @generated
	 */
	void setTitulo(String value);

	/**
	 * Returns the value of the '<em><b>Is Borrowed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Borrowed</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Borrowed</em>' attribute.
	 * @see #setIsBorrowed(boolean)
	 * @see Model.ModelPackage#getTese_IsBorrowed()
	 * @model dataType="org.eclipse.uml2.types.Boolean" required="true" ordered="false"
	 * @generated
	 */
	boolean isBorrowed();

	/**
	 * Sets the value of the '{@link Model.Tese#isBorrowed <em>Is Borrowed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Borrowed</em>' attribute.
	 * @see #isBorrowed()
	 * @generated
	 */
	void setIsBorrowed(boolean value);

	/**
	 * Returns the value of the '<em><b>Autores</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Autores</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Autores</em>' attribute.
	 * @see #setAutores(String)
	 * @see Model.ModelPackage#getTese_Autores()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getAutores();

	/**
	 * Sets the value of the '{@link Model.Tese#getAutores <em>Autores</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Autores</em>' attribute.
	 * @see #getAutores()
	 * @generated
	 */
	void setAutores(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false" LibNumberDataType="org.eclipse.uml2.types.Integer" LibNumberRequired="true" LibNumberOrdered="false"
	 * @generated
	 */
	String getInfo(int LibNumber);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model LibNumberDataType="org.eclipse.uml2.types.Integer" LibNumberRequired="true" LibNumberOrdered="false"
	 * @generated
	 */
	void setInfo(int LibNumber);

} // Tese
