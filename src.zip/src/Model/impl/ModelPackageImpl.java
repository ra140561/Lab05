/**
 */
package Model.impl;

import Model.Aluno;
import Model.Biblioteca;
import Model.Departamentos;
import Model.DeptoA;
import Model.DeptoB;
import Model.Emprestimo;
import Model.Exemplar;
import Model.Funcionario;
import Model.Livro;
import Model.Manual;
import Model.ModelFactory;
import Model.ModelPackage;
import Model.Periodico;
import Model.Professor;
import Model.Publicacao;
import Model.Terminal;
import Model.Tese;
import Model.Usuario;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.uml2.types.TypesPackage;

import org.eclipse.uml2.types.impl.TypesPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ModelPackageImpl extends EPackageImpl implements ModelPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass terminalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass bibliotecaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass emprestimoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass exemplarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass publicacaoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass livroEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass periodicoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass teseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass manualEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass usuarioEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass alunoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass professorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass funcionarioEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass deptoAEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass departamentosEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass deptoBEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see Model.ModelPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ModelPackageImpl() {
		super(eNS_URI, ModelFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link ModelPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ModelPackage init() {
		if (isInited) return (ModelPackage)EPackage.Registry.INSTANCE.getEPackage(ModelPackage.eNS_URI);

		// Obtain or create and register package
		ModelPackageImpl theModelPackage = (ModelPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof ModelPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new ModelPackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		TypesPackageImpl theTypesPackage = (TypesPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(TypesPackage.eNS_URI) instanceof TypesPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(TypesPackage.eNS_URI) : TypesPackage.eINSTANCE);

		// Create package meta-data objects
		theModelPackage.createPackageContents();
		theTypesPackage.createPackageContents();

		// Initialize created meta-data
		theModelPackage.initializePackageContents();
		theTypesPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theModelPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ModelPackage.eNS_URI, theModelPackage);
		return theModelPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTerminal() {
		return terminalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTerminal_SessionName() {
		return (EAttribute)terminalEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTerminal__Authentication__String_String() {
		return terminalEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTerminal__CheckAvailability__int_String() {
		return terminalEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBiblioteca() {
		return bibliotecaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBiblioteca_Name() {
		return (EAttribute)bibliotecaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBiblioteca_Address() {
		return (EAttribute)bibliotecaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBiblioteca_SystemDate() {
		return (EAttribute)bibliotecaEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getBiblioteca__GetSystemDate__String() {
		return bibliotecaEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEmprestimo() {
		return emprestimoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEmprestimo_DevolutionDate() {
		return (EAttribute)emprestimoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEmprestimo_BorrowProtocol() {
		return (EAttribute)emprestimoEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEmprestimo__GetDevollutionCharges__int() {
		return emprestimoEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEmprestimo__IsAvaiable__int() {
		return emprestimoEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEmprestimo__SetDevolutionDate() {
		return emprestimoEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEmprestimo__SetBorrowProtocol() {
		return emprestimoEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEmprestimo__CancelReservation__int() {
		return emprestimoEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEmprestimo__AddReservation__int() {
		return emprestimoEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEmprestimo__SetCharges() {
		return emprestimoEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getExemplar() {
		return exemplarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExemplar_Autores() {
		return (EAttribute)exemplarEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExemplar_Titulo() {
		return (EAttribute)exemplarEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExemplar_Availability() {
		return (EAttribute)exemplarEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExemplar_LibNumber() {
		return (EAttribute)exemplarEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExemplar_IsBlocked() {
		return (EAttribute)exemplarEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getExemplar__UpdateCopies__int() {
		return exemplarEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getExemplar__Block__int() {
		return exemplarEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getExemplar__Unblock__int() {
		return exemplarEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPublicacao() {
		return publicacaoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPublicacao_LibNumber() {
		return (EAttribute)publicacaoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPublicacao__AddNewPublication__int() {
		return publicacaoEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPublicacao__RemovePublication__int() {
		return publicacaoEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPublicacao__GetLibnumber() {
		return publicacaoEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPublicacao__SetLibnumber() {
		return publicacaoEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLivro() {
		return livroEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLivro_Titulo() {
		return (EAttribute)livroEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLivro_Autores() {
		return (EAttribute)livroEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLivro_IsBorrowed() {
		return (EAttribute)livroEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getLivro__GetInfo__int() {
		return livroEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getLivro__SetInfo__int() {
		return livroEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPeriodico() {
		return periodicoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPeriodico_Titulo() {
		return (EAttribute)periodicoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPeriodico_Autores() {
		return (EAttribute)periodicoEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPeriodico_IsBorrowed() {
		return (EAttribute)periodicoEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPeriodico__GetInfo__int() {
		return periodicoEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPeriodico__SetInfo__int() {
		return periodicoEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTese() {
		return teseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTese_Titulo() {
		return (EAttribute)teseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTese_IsBorrowed() {
		return (EAttribute)teseEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTese_Autores() {
		return (EAttribute)teseEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTese__GetInfo__int() {
		return teseEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTese__SetInfo__int() {
		return teseEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getManual() {
		return manualEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getManual_Titulo() {
		return (EAttribute)manualEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getManual_Autores() {
		return (EAttribute)manualEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getManual_IsBorrowed() {
		return (EAttribute)manualEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getManual__GetInfo__int() {
		return manualEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getManual__SetInfo__int() {
		return manualEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUsuario() {
		return usuarioEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUsuario_CPF() {
		return (EAttribute)usuarioEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUsuario_FirstName() {
		return (EAttribute)usuarioEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUsuario_LastName() {
		return (EAttribute)usuarioEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUsuario_FullName() {
		return (EAttribute)usuarioEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUsuario_ChargesStatus() {
		return (EAttribute)usuarioEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getUsuario__RegisterUserAtDataBase__int() {
		return usuarioEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getUsuario__SetChargeStatus__int() {
		return usuarioEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAluno() {
		return alunoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAluno_Email() {
		return (EAttribute)alunoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAluno_Address() {
		return (EAttribute)alunoEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAluno_CEP() {
		return (EAttribute)alunoEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAluno__GetFirstName() {
		return alunoEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAluno__SetFullName() {
		return alunoEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAluno__ToRegisterStudent__int() {
		return alunoEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAluno__GetLastName() {
		return alunoEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAluno__SetCPF() {
		return alunoEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAluno__SetCEP() {
		return alunoEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAluno__CALLForm() {
		return alunoEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAluno__GetCep() {
		return alunoEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAluno__GetCPF() {
		return alunoEClass.getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAluno__SetFullAddress() {
		return alunoEClass.getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProfessor() {
		return professorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProfessor_Address() {
		return (EAttribute)professorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProfessor_Email() {
		return (EAttribute)professorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProfessor_CEP() {
		return (EAttribute)professorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProfessor__SetCEP() {
		return professorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProfessor__GetLastName() {
		return professorEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProfessor__GetFirstName() {
		return professorEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProfessor__SetFullName() {
		return professorEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProfessor__ToRegisterProfessor__int() {
		return professorEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProfessor__SetCPF() {
		return professorEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProfessor__CALLForm() {
		return professorEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProfessor__GetCep() {
		return professorEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProfessor__GetCPF() {
		return professorEClass.getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getProfessor__SetFullAddress() {
		return professorEClass.getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFuncionario() {
		return funcionarioEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFuncionario_CEP() {
		return (EAttribute)funcionarioEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFuncionario_Email() {
		return (EAttribute)funcionarioEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFuncionario_Address() {
		return (EAttribute)funcionarioEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFuncionario__SetFullName() {
		return funcionarioEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFuncionario__SetCEP() {
		return funcionarioEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFuncionario__SetCPF() {
		return funcionarioEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFuncionario__ToRegisterEmployee__int() {
		return funcionarioEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFuncionario__GetFirstName() {
		return funcionarioEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFuncionario__GetLastName() {
		return funcionarioEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFuncionario__CALLForm() {
		return funcionarioEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFuncionario__GetCep() {
		return funcionarioEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFuncionario__SetFullAddress() {
		return funcionarioEClass.getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFuncionario__GetCPF() {
		return funcionarioEClass.getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDeptoA() {
		return deptoAEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeptoA_DeptName() {
		return (EAttribute)deptoAEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeptoA__GetDeptname() {
		return deptoAEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeptoA__SetDeptName() {
		return deptoAEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDepartamentos() {
		return departamentosEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDeptoB() {
		return deptoBEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeptoB_DeptName() {
		return (EAttribute)deptoBEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeptoB__GetDeptname() {
		return deptoBEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDeptoB__SetDeptName() {
		return deptoBEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelFactory getModelFactory() {
		return (ModelFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		terminalEClass = createEClass(TERMINAL);
		createEAttribute(terminalEClass, TERMINAL__SESSION_NAME);
		createEOperation(terminalEClass, TERMINAL___AUTHENTICATION__STRING_STRING);
		createEOperation(terminalEClass, TERMINAL___CHECK_AVAILABILITY__INT_STRING);

		bibliotecaEClass = createEClass(BIBLIOTECA);
		createEAttribute(bibliotecaEClass, BIBLIOTECA__NAME);
		createEAttribute(bibliotecaEClass, BIBLIOTECA__ADDRESS);
		createEAttribute(bibliotecaEClass, BIBLIOTECA__SYSTEM_DATE);
		createEOperation(bibliotecaEClass, BIBLIOTECA___GET_SYSTEM_DATE__STRING);

		emprestimoEClass = createEClass(EMPRESTIMO);
		createEAttribute(emprestimoEClass, EMPRESTIMO__DEVOLUTION_DATE);
		createEAttribute(emprestimoEClass, EMPRESTIMO__BORROW_PROTOCOL);
		createEOperation(emprestimoEClass, EMPRESTIMO___GET_DEVOLLUTION_CHARGES__INT);
		createEOperation(emprestimoEClass, EMPRESTIMO___IS_AVAIABLE__INT);
		createEOperation(emprestimoEClass, EMPRESTIMO___SET_DEVOLUTION_DATE);
		createEOperation(emprestimoEClass, EMPRESTIMO___SET_BORROW_PROTOCOL);
		createEOperation(emprestimoEClass, EMPRESTIMO___CANCEL_RESERVATION__INT);
		createEOperation(emprestimoEClass, EMPRESTIMO___ADD_RESERVATION__INT);
		createEOperation(emprestimoEClass, EMPRESTIMO___SET_CHARGES);

		exemplarEClass = createEClass(EXEMPLAR);
		createEAttribute(exemplarEClass, EXEMPLAR__AUTORES);
		createEAttribute(exemplarEClass, EXEMPLAR__TITULO);
		createEAttribute(exemplarEClass, EXEMPLAR__AVAILABILITY);
		createEAttribute(exemplarEClass, EXEMPLAR__LIB_NUMBER);
		createEAttribute(exemplarEClass, EXEMPLAR__IS_BLOCKED);
		createEOperation(exemplarEClass, EXEMPLAR___UPDATE_COPIES__INT);
		createEOperation(exemplarEClass, EXEMPLAR___BLOCK__INT);
		createEOperation(exemplarEClass, EXEMPLAR___UNBLOCK__INT);

		publicacaoEClass = createEClass(PUBLICACAO);
		createEAttribute(publicacaoEClass, PUBLICACAO__LIB_NUMBER);
		createEOperation(publicacaoEClass, PUBLICACAO___ADD_NEW_PUBLICATION__INT);
		createEOperation(publicacaoEClass, PUBLICACAO___REMOVE_PUBLICATION__INT);
		createEOperation(publicacaoEClass, PUBLICACAO___GET_LIBNUMBER);
		createEOperation(publicacaoEClass, PUBLICACAO___SET_LIBNUMBER);

		livroEClass = createEClass(LIVRO);
		createEAttribute(livroEClass, LIVRO__TITULO);
		createEAttribute(livroEClass, LIVRO__AUTORES);
		createEAttribute(livroEClass, LIVRO__IS_BORROWED);
		createEOperation(livroEClass, LIVRO___GET_INFO__INT);
		createEOperation(livroEClass, LIVRO___SET_INFO__INT);

		periodicoEClass = createEClass(PERIODICO);
		createEAttribute(periodicoEClass, PERIODICO__TITULO);
		createEAttribute(periodicoEClass, PERIODICO__AUTORES);
		createEAttribute(periodicoEClass, PERIODICO__IS_BORROWED);
		createEOperation(periodicoEClass, PERIODICO___GET_INFO__INT);
		createEOperation(periodicoEClass, PERIODICO___SET_INFO__INT);

		teseEClass = createEClass(TESE);
		createEAttribute(teseEClass, TESE__TITULO);
		createEAttribute(teseEClass, TESE__IS_BORROWED);
		createEAttribute(teseEClass, TESE__AUTORES);
		createEOperation(teseEClass, TESE___GET_INFO__INT);
		createEOperation(teseEClass, TESE___SET_INFO__INT);

		manualEClass = createEClass(MANUAL);
		createEAttribute(manualEClass, MANUAL__TITULO);
		createEAttribute(manualEClass, MANUAL__AUTORES);
		createEAttribute(manualEClass, MANUAL__IS_BORROWED);
		createEOperation(manualEClass, MANUAL___GET_INFO__INT);
		createEOperation(manualEClass, MANUAL___SET_INFO__INT);

		usuarioEClass = createEClass(USUARIO);
		createEAttribute(usuarioEClass, USUARIO__CPF);
		createEAttribute(usuarioEClass, USUARIO__FIRST_NAME);
		createEAttribute(usuarioEClass, USUARIO__LAST_NAME);
		createEAttribute(usuarioEClass, USUARIO__FULL_NAME);
		createEAttribute(usuarioEClass, USUARIO__CHARGES_STATUS);
		createEOperation(usuarioEClass, USUARIO___REGISTER_USER_AT_DATA_BASE__INT);
		createEOperation(usuarioEClass, USUARIO___SET_CHARGE_STATUS__INT);

		alunoEClass = createEClass(ALUNO);
		createEAttribute(alunoEClass, ALUNO__EMAIL);
		createEAttribute(alunoEClass, ALUNO__ADDRESS);
		createEAttribute(alunoEClass, ALUNO__CEP);
		createEOperation(alunoEClass, ALUNO___GET_FIRST_NAME);
		createEOperation(alunoEClass, ALUNO___SET_FULL_NAME);
		createEOperation(alunoEClass, ALUNO___TO_REGISTER_STUDENT__INT);
		createEOperation(alunoEClass, ALUNO___GET_LAST_NAME);
		createEOperation(alunoEClass, ALUNO___SET_CPF);
		createEOperation(alunoEClass, ALUNO___SET_CEP);
		createEOperation(alunoEClass, ALUNO___CALL_FORM);
		createEOperation(alunoEClass, ALUNO___GET_CEP);
		createEOperation(alunoEClass, ALUNO___GET_CPF);
		createEOperation(alunoEClass, ALUNO___SET_FULL_ADDRESS);

		professorEClass = createEClass(PROFESSOR);
		createEAttribute(professorEClass, PROFESSOR__ADDRESS);
		createEAttribute(professorEClass, PROFESSOR__EMAIL);
		createEAttribute(professorEClass, PROFESSOR__CEP);
		createEOperation(professorEClass, PROFESSOR___SET_CEP);
		createEOperation(professorEClass, PROFESSOR___GET_LAST_NAME);
		createEOperation(professorEClass, PROFESSOR___GET_FIRST_NAME);
		createEOperation(professorEClass, PROFESSOR___SET_FULL_NAME);
		createEOperation(professorEClass, PROFESSOR___TO_REGISTER_PROFESSOR__INT);
		createEOperation(professorEClass, PROFESSOR___SET_CPF);
		createEOperation(professorEClass, PROFESSOR___CALL_FORM);
		createEOperation(professorEClass, PROFESSOR___GET_CEP);
		createEOperation(professorEClass, PROFESSOR___GET_CPF);
		createEOperation(professorEClass, PROFESSOR___SET_FULL_ADDRESS);

		funcionarioEClass = createEClass(FUNCIONARIO);
		createEAttribute(funcionarioEClass, FUNCIONARIO__CEP);
		createEAttribute(funcionarioEClass, FUNCIONARIO__EMAIL);
		createEAttribute(funcionarioEClass, FUNCIONARIO__ADDRESS);
		createEOperation(funcionarioEClass, FUNCIONARIO___SET_FULL_NAME);
		createEOperation(funcionarioEClass, FUNCIONARIO___SET_CEP);
		createEOperation(funcionarioEClass, FUNCIONARIO___SET_CPF);
		createEOperation(funcionarioEClass, FUNCIONARIO___TO_REGISTER_EMPLOYEE__INT);
		createEOperation(funcionarioEClass, FUNCIONARIO___GET_FIRST_NAME);
		createEOperation(funcionarioEClass, FUNCIONARIO___GET_LAST_NAME);
		createEOperation(funcionarioEClass, FUNCIONARIO___CALL_FORM);
		createEOperation(funcionarioEClass, FUNCIONARIO___GET_CEP);
		createEOperation(funcionarioEClass, FUNCIONARIO___SET_FULL_ADDRESS);
		createEOperation(funcionarioEClass, FUNCIONARIO___GET_CPF);

		deptoAEClass = createEClass(DEPTO_A);
		createEAttribute(deptoAEClass, DEPTO_A__DEPT_NAME);
		createEOperation(deptoAEClass, DEPTO_A___GET_DEPTNAME);
		createEOperation(deptoAEClass, DEPTO_A___SET_DEPT_NAME);

		departamentosEClass = createEClass(DEPARTAMENTOS);

		deptoBEClass = createEClass(DEPTO_B);
		createEAttribute(deptoBEClass, DEPTO_B__DEPT_NAME);
		createEOperation(deptoBEClass, DEPTO_B___GET_DEPTNAME);
		createEOperation(deptoBEClass, DEPTO_B___SET_DEPT_NAME);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		TypesPackage theTypesPackage = (TypesPackage)EPackage.Registry.INSTANCE.getEPackage(TypesPackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		livroEClass.getESuperTypes().add(this.getPublicacao());
		periodicoEClass.getESuperTypes().add(this.getPublicacao());
		teseEClass.getESuperTypes().add(this.getPublicacao());
		manualEClass.getESuperTypes().add(this.getPublicacao());
		alunoEClass.getESuperTypes().add(this.getUsuario());
		professorEClass.getESuperTypes().add(this.getUsuario());
		funcionarioEClass.getESuperTypes().add(this.getUsuario());
		deptoAEClass.getESuperTypes().add(this.getDepartamentos());
		deptoBEClass.getESuperTypes().add(this.getDepartamentos());

		// Initialize classes, features, and operations; add parameters
		initEClass(terminalEClass, Terminal.class, "Terminal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTerminal_SessionName(), theTypesPackage.getInteger(), "SessionName", null, 1, 1, Terminal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		EOperation op = initEOperation(getTerminal__Authentication__String_String(), theTypesPackage.getInteger(), "Authentication", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getString(), "Username", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getString(), "Pass", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getTerminal__CheckAvailability__int_String(), theTypesPackage.getBoolean(), "checkAvailability", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNum", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getString(), "PubName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(bibliotecaEClass, Biblioteca.class, "Biblioteca", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getBiblioteca_Name(), theTypesPackage.getString(), "Name", null, 1, 1, Biblioteca.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getBiblioteca_Address(), theTypesPackage.getString(), "Address", null, 1, 1, Biblioteca.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getBiblioteca_SystemDate(), theTypesPackage.getString(), "SystemDate", null, 1, 1, Biblioteca.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getBiblioteca__GetSystemDate__String(), null, "getSystemDate", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getString(), "LibraryName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(emprestimoEClass, Emprestimo.class, "Emprestimo", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEmprestimo_DevolutionDate(), theTypesPackage.getString(), "DevolutionDate", null, 1, 1, Emprestimo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getEmprestimo_BorrowProtocol(), theTypesPackage.getInteger(), "BorrowProtocol", null, 1, 1, Emprestimo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getEmprestimo__GetDevollutionCharges__int(), theTypesPackage.getBoolean(), "getDevollutionCharges", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "CPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getEmprestimo__IsAvaiable__int(), theTypesPackage.getBoolean(), "isAvaiable", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNum", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getEmprestimo__SetDevolutionDate(), null, "setDevolutionDate", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getEmprestimo__SetBorrowProtocol(), null, "setBorrowProtocol", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getEmprestimo__CancelReservation__int(), null, "cancelReservation", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "BorrowProtocol", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getEmprestimo__AddReservation__int(), null, "addReservation", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNum", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getEmprestimo__SetCharges(), null, "setCharges", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(exemplarEClass, Exemplar.class, "Exemplar", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getExemplar_Autores(), theTypesPackage.getString(), "Autores", null, 1, 1, Exemplar.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getExemplar_Titulo(), theTypesPackage.getString(), "Titulo", null, 1, 1, Exemplar.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getExemplar_Availability(), theTypesPackage.getBoolean(), "Availability", null, 1, 1, Exemplar.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getExemplar_LibNumber(), theTypesPackage.getInteger(), "LibNumber", null, 1, 1, Exemplar.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getExemplar_IsBlocked(), theTypesPackage.getBoolean(), "isBlocked", null, 1, 1, Exemplar.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getExemplar__UpdateCopies__int(), null, "updateCopies", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNum", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getExemplar__Block__int(), null, "block", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNum", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getExemplar__Unblock__int(), null, "unblock", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNum", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(publicacaoEClass, Publicacao.class, "Publicacao", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPublicacao_LibNumber(), theTypesPackage.getInteger(), "LibNumber", null, 1, 1, Publicacao.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getPublicacao__AddNewPublication__int(), null, "addNewPublication", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNum", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getPublicacao__RemovePublication__int(), null, "removePublication", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNum", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPublicacao__GetLibnumber(), null, "getLibnumber", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getPublicacao__SetLibnumber(), null, "setLibnumber", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(livroEClass, Livro.class, "Livro", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLivro_Titulo(), theTypesPackage.getString(), "Titulo", null, 1, 1, Livro.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getLivro_Autores(), theTypesPackage.getString(), "Autores", null, 1, 1, Livro.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getLivro_IsBorrowed(), theTypesPackage.getBoolean(), "isBorrowed", null, 1, 1, Livro.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getLivro__GetInfo__int(), theTypesPackage.getString(), "getInfo", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNumber", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getLivro__SetInfo__int(), null, "setInfo", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNumber", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(periodicoEClass, Periodico.class, "Periodico", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPeriodico_Titulo(), theTypesPackage.getString(), "Titulo", null, 1, 1, Periodico.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPeriodico_Autores(), theTypesPackage.getString(), "Autores", null, 1, 1, Periodico.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getPeriodico_IsBorrowed(), theTypesPackage.getBoolean(), "isBorrowed", null, 1, 1, Periodico.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getPeriodico__GetInfo__int(), theTypesPackage.getString(), "getInfo", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNumber", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getPeriodico__SetInfo__int(), null, "setInfo", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNumber", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(teseEClass, Tese.class, "Tese", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTese_Titulo(), theTypesPackage.getString(), "Titulo", null, 1, 1, Tese.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getTese_IsBorrowed(), theTypesPackage.getBoolean(), "isBorrowed", null, 1, 1, Tese.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getTese_Autores(), theTypesPackage.getString(), "Autores", null, 1, 1, Tese.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getTese__GetInfo__int(), theTypesPackage.getString(), "getInfo", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNumber", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getTese__SetInfo__int(), null, "setInfo", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNumber", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(manualEClass, Manual.class, "Manual", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getManual_Titulo(), theTypesPackage.getString(), "Titulo", null, 1, 1, Manual.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getManual_Autores(), theTypesPackage.getString(), "Autores", null, 1, 1, Manual.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getManual_IsBorrowed(), theTypesPackage.getBoolean(), "isBorrowed", null, 1, 1, Manual.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getManual__GetInfo__int(), theTypesPackage.getString(), "getInfo", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNumber", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getManual__SetInfo__int(), null, "setInfo", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "LibNumber", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(usuarioEClass, Usuario.class, "Usuario", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getUsuario_CPF(), theTypesPackage.getString(), "CPF", null, 1, 1, Usuario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getUsuario_FirstName(), theTypesPackage.getString(), "FirstName", null, 1, 1, Usuario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getUsuario_LastName(), theTypesPackage.getString(), "LastName", null, 1, 1, Usuario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getUsuario_FullName(), theTypesPackage.getString(), "FullName", null, 1, 1, Usuario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getUsuario_ChargesStatus(), theTypesPackage.getInteger(), "chargesStatus", null, 1, 1, Usuario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getUsuario__RegisterUserAtDataBase__int(), null, "registerUserAtDataBase", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "CPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getUsuario__SetChargeStatus__int(), null, "setChargeStatus", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "CPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(alunoEClass, Aluno.class, "Aluno", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAluno_Email(), theTypesPackage.getString(), "Email", null, 1, 1, Aluno.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getAluno_Address(), theTypesPackage.getString(), "Address", null, 1, 1, Aluno.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getAluno_CEP(), theTypesPackage.getInteger(), "CEP", null, 1, 1, Aluno.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getAluno__GetFirstName(), theTypesPackage.getString(), "getFirstName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getAluno__SetFullName(), null, "setFullName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getAluno__ToRegisterStudent__int(), null, "toRegisterStudent", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "CPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getAluno__GetLastName(), theTypesPackage.getString(), "getLastName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getAluno__SetCPF(), theTypesPackage.getBoolean(), "setCPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getAluno__SetCEP(), theTypesPackage.getBoolean(), "setCEP", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getAluno__CALLForm(), null, "CALLForm", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getAluno__GetCep(), null, "getCep", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getAluno__GetCPF(), null, "getCPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getAluno__SetFullAddress(), null, "setFullAddress", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(professorEClass, Professor.class, "Professor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getProfessor_Address(), theTypesPackage.getString(), "Address", null, 1, 1, Professor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getProfessor_Email(), theTypesPackage.getString(), "Email", null, 1, 1, Professor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getProfessor_CEP(), theTypesPackage.getInteger(), "CEP", null, 1, 1, Professor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getProfessor__SetCEP(), theTypesPackage.getBoolean(), "setCEP", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProfessor__GetLastName(), theTypesPackage.getString(), "getLastName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProfessor__GetFirstName(), theTypesPackage.getString(), "getFirstName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProfessor__SetFullName(), null, "setFullName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getProfessor__ToRegisterProfessor__int(), null, "toRegisterProfessor", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "CPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProfessor__SetCPF(), theTypesPackage.getBoolean(), "setCPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProfessor__CALLForm(), null, "CALLForm", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProfessor__GetCep(), null, "getCep", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProfessor__GetCPF(), null, "getCPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getProfessor__SetFullAddress(), null, "setFullAddress", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(funcionarioEClass, Funcionario.class, "Funcionario", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFuncionario_CEP(), theTypesPackage.getInteger(), "CEP", null, 1, 1, Funcionario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getFuncionario_Email(), theTypesPackage.getString(), "Email", null, 1, 1, Funcionario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getFuncionario_Address(), theTypesPackage.getString(), "Address", null, 1, 1, Funcionario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getFuncionario__SetFullName(), null, "setFullName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getFuncionario__SetCEP(), theTypesPackage.getBoolean(), "setCEP", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getFuncionario__SetCPF(), theTypesPackage.getBoolean(), "setCPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getFuncionario__ToRegisterEmployee__int(), null, "toRegisterEmployee", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, theTypesPackage.getInteger(), "CPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getFuncionario__GetFirstName(), theTypesPackage.getString(), "getFirstName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getFuncionario__GetLastName(), theTypesPackage.getString(), "getLastName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getFuncionario__CALLForm(), null, "CALLForm", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getFuncionario__GetCep(), null, "getCep", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getFuncionario__SetFullAddress(), null, "setFullAddress", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getFuncionario__GetCPF(), null, "getCPF", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(deptoAEClass, DeptoA.class, "DeptoA", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDeptoA_DeptName(), theTypesPackage.getString(), "DeptName", null, 1, 1, DeptoA.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getDeptoA__GetDeptname(), null, "getDeptname", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDeptoA__SetDeptName(), null, "setDeptName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(departamentosEClass, Departamentos.class, "Departamentos", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(deptoBEClass, DeptoB.class, "DeptoB", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDeptoB_DeptName(), theTypesPackage.getString(), "DeptName", null, 1, 1, DeptoB.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getDeptoB__GetDeptname(), null, "getDeptname", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDeptoB__SetDeptName(), null, "setDeptName", 1, 1, IS_UNIQUE, !IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //ModelPackageImpl
