/**
 */
package Model.impl;

import Model.Exemplar;
import Model.ModelPackage;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Exemplar</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link Model.impl.ExemplarImpl#getAutores <em>Autores</em>}</li>
 *   <li>{@link Model.impl.ExemplarImpl#getTitulo <em>Titulo</em>}</li>
 *   <li>{@link Model.impl.ExemplarImpl#isAvailability <em>Availability</em>}</li>
 *   <li>{@link Model.impl.ExemplarImpl#getLibNumber <em>Lib Number</em>}</li>
 *   <li>{@link Model.impl.ExemplarImpl#isBlocked <em>Is Blocked</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ExemplarImpl extends MinimalEObjectImpl.Container implements Exemplar {
	/**
	 * The default value of the '{@link #getAutores() <em>Autores</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAutores()
	 * @generated
	 * @ordered
	 */
	protected static final String AUTORES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAutores() <em>Autores</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAutores()
	 * @generated
	 * @ordered
	 */
	protected String autores = AUTORES_EDEFAULT;

	/**
	 * The default value of the '{@link #getTitulo() <em>Titulo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitulo()
	 * @generated
	 * @ordered
	 */
	protected static final String TITULO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTitulo() <em>Titulo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitulo()
	 * @generated
	 * @ordered
	 */
	protected String titulo = TITULO_EDEFAULT;

	/**
	 * The default value of the '{@link #isAvailability() <em>Availability</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isAvailability()
	 * @generated
	 * @ordered
	 */
	protected static final boolean AVAILABILITY_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isAvailability() <em>Availability</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isAvailability()
	 * @generated
	 * @ordered
	 */
	protected boolean availability = AVAILABILITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getLibNumber() <em>Lib Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLibNumber()
	 * @generated
	 * @ordered
	 */
	protected static final int LIB_NUMBER_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getLibNumber() <em>Lib Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLibNumber()
	 * @generated
	 * @ordered
	 */
	protected int libNumber = LIB_NUMBER_EDEFAULT;

	/**
	 * The default value of the '{@link #isBlocked() <em>Is Blocked</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBlocked()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_BLOCKED_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isBlocked() <em>Is Blocked</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBlocked()
	 * @generated
	 * @ordered
	 */
	protected boolean isBlocked = IS_BLOCKED_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ExemplarImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelPackage.Literals.EXEMPLAR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAutores() {
		return autores;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAutores(String newAutores) {
		String oldAutores = autores;
		autores = newAutores;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EXEMPLAR__AUTORES, oldAutores, autores));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTitulo() {
		return titulo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTitulo(String newTitulo) {
		String oldTitulo = titulo;
		titulo = newTitulo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EXEMPLAR__TITULO, oldTitulo, titulo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAvailability() {
		return availability;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAvailability(boolean newAvailability) {
		boolean oldAvailability = availability;
		availability = newAvailability;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EXEMPLAR__AVAILABILITY, oldAvailability, availability));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getLibNumber() {
		return libNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLibNumber(int newLibNumber) {
		int oldLibNumber = libNumber;
		libNumber = newLibNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EXEMPLAR__LIB_NUMBER, oldLibNumber, libNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isBlocked() {
		return isBlocked;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsBlocked(boolean newIsBlocked) {
		boolean oldIsBlocked = isBlocked;
		isBlocked = newIsBlocked;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EXEMPLAR__IS_BLOCKED, oldIsBlocked, isBlocked));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void updateCopies(int LibNum) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void block(int LibNum) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unblock(int LibNum) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ModelPackage.EXEMPLAR__AUTORES:
				return getAutores();
			case ModelPackage.EXEMPLAR__TITULO:
				return getTitulo();
			case ModelPackage.EXEMPLAR__AVAILABILITY:
				return isAvailability();
			case ModelPackage.EXEMPLAR__LIB_NUMBER:
				return getLibNumber();
			case ModelPackage.EXEMPLAR__IS_BLOCKED:
				return isBlocked();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ModelPackage.EXEMPLAR__AUTORES:
				setAutores((String)newValue);
				return;
			case ModelPackage.EXEMPLAR__TITULO:
				setTitulo((String)newValue);
				return;
			case ModelPackage.EXEMPLAR__AVAILABILITY:
				setAvailability((Boolean)newValue);
				return;
			case ModelPackage.EXEMPLAR__LIB_NUMBER:
				setLibNumber((Integer)newValue);
				return;
			case ModelPackage.EXEMPLAR__IS_BLOCKED:
				setIsBlocked((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ModelPackage.EXEMPLAR__AUTORES:
				setAutores(AUTORES_EDEFAULT);
				return;
			case ModelPackage.EXEMPLAR__TITULO:
				setTitulo(TITULO_EDEFAULT);
				return;
			case ModelPackage.EXEMPLAR__AVAILABILITY:
				setAvailability(AVAILABILITY_EDEFAULT);
				return;
			case ModelPackage.EXEMPLAR__LIB_NUMBER:
				setLibNumber(LIB_NUMBER_EDEFAULT);
				return;
			case ModelPackage.EXEMPLAR__IS_BLOCKED:
				setIsBlocked(IS_BLOCKED_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ModelPackage.EXEMPLAR__AUTORES:
				return AUTORES_EDEFAULT == null ? autores != null : !AUTORES_EDEFAULT.equals(autores);
			case ModelPackage.EXEMPLAR__TITULO:
				return TITULO_EDEFAULT == null ? titulo != null : !TITULO_EDEFAULT.equals(titulo);
			case ModelPackage.EXEMPLAR__AVAILABILITY:
				return availability != AVAILABILITY_EDEFAULT;
			case ModelPackage.EXEMPLAR__LIB_NUMBER:
				return libNumber != LIB_NUMBER_EDEFAULT;
			case ModelPackage.EXEMPLAR__IS_BLOCKED:
				return isBlocked != IS_BLOCKED_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case ModelPackage.EXEMPLAR___UPDATE_COPIES__INT:
				updateCopies((Integer)arguments.get(0));
				return null;
			case ModelPackage.EXEMPLAR___BLOCK__INT:
				block((Integer)arguments.get(0));
				return null;
			case ModelPackage.EXEMPLAR___UNBLOCK__INT:
				unblock((Integer)arguments.get(0));
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Autores: ");
		result.append(autores);
		result.append(", Titulo: ");
		result.append(titulo);
		result.append(", Availability: ");
		result.append(availability);
		result.append(", LibNumber: ");
		result.append(libNumber);
		result.append(", isBlocked: ");
		result.append(isBlocked);
		result.append(')');
		return result.toString();
	}

} //ExemplarImpl
