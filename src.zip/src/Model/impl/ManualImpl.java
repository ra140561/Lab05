/**
 */
package Model.impl;

import Model.Manual;
import Model.ModelPackage;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Manual</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link Model.impl.ManualImpl#getTitulo <em>Titulo</em>}</li>
 *   <li>{@link Model.impl.ManualImpl#getAutores <em>Autores</em>}</li>
 *   <li>{@link Model.impl.ManualImpl#isBorrowed <em>Is Borrowed</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ManualImpl extends PublicacaoImpl implements Manual {
	/**
	 * The default value of the '{@link #getTitulo() <em>Titulo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitulo()
	 * @generated
	 * @ordered
	 */
	protected static final String TITULO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTitulo() <em>Titulo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitulo()
	 * @generated
	 * @ordered
	 */
	protected String titulo = TITULO_EDEFAULT;

	/**
	 * The default value of the '{@link #getAutores() <em>Autores</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAutores()
	 * @generated
	 * @ordered
	 */
	protected static final String AUTORES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAutores() <em>Autores</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAutores()
	 * @generated
	 * @ordered
	 */
	protected String autores = AUTORES_EDEFAULT;

	/**
	 * The default value of the '{@link #isBorrowed() <em>Is Borrowed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBorrowed()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_BORROWED_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isBorrowed() <em>Is Borrowed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBorrowed()
	 * @generated
	 * @ordered
	 */
	protected boolean isBorrowed = IS_BORROWED_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ManualImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelPackage.Literals.MANUAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTitulo() {
		return titulo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTitulo(String newTitulo) {
		String oldTitulo = titulo;
		titulo = newTitulo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.MANUAL__TITULO, oldTitulo, titulo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAutores() {
		return autores;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAutores(String newAutores) {
		String oldAutores = autores;
		autores = newAutores;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.MANUAL__AUTORES, oldAutores, autores));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isBorrowed() {
		return isBorrowed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsBorrowed(boolean newIsBorrowed) {
		boolean oldIsBorrowed = isBorrowed;
		isBorrowed = newIsBorrowed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.MANUAL__IS_BORROWED, oldIsBorrowed, isBorrowed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInfo(int LibNumber) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInfo(int LibNumber) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ModelPackage.MANUAL__TITULO:
				return getTitulo();
			case ModelPackage.MANUAL__AUTORES:
				return getAutores();
			case ModelPackage.MANUAL__IS_BORROWED:
				return isBorrowed();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ModelPackage.MANUAL__TITULO:
				setTitulo((String)newValue);
				return;
			case ModelPackage.MANUAL__AUTORES:
				setAutores((String)newValue);
				return;
			case ModelPackage.MANUAL__IS_BORROWED:
				setIsBorrowed((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ModelPackage.MANUAL__TITULO:
				setTitulo(TITULO_EDEFAULT);
				return;
			case ModelPackage.MANUAL__AUTORES:
				setAutores(AUTORES_EDEFAULT);
				return;
			case ModelPackage.MANUAL__IS_BORROWED:
				setIsBorrowed(IS_BORROWED_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ModelPackage.MANUAL__TITULO:
				return TITULO_EDEFAULT == null ? titulo != null : !TITULO_EDEFAULT.equals(titulo);
			case ModelPackage.MANUAL__AUTORES:
				return AUTORES_EDEFAULT == null ? autores != null : !AUTORES_EDEFAULT.equals(autores);
			case ModelPackage.MANUAL__IS_BORROWED:
				return isBorrowed != IS_BORROWED_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case ModelPackage.MANUAL___GET_INFO__INT:
				return getInfo((Integer)arguments.get(0));
			case ModelPackage.MANUAL___SET_INFO__INT:
				setInfo((Integer)arguments.get(0));
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Titulo: ");
		result.append(titulo);
		result.append(", Autores: ");
		result.append(autores);
		result.append(", isBorrowed: ");
		result.append(isBorrowed);
		result.append(')');
		return result.toString();
	}

} //ManualImpl
