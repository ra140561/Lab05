/**
 */
package Model.impl;

import Model.Emprestimo;
import Model.ModelPackage;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Emprestimo</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link Model.impl.EmprestimoImpl#getDevolutionDate <em>Devolution Date</em>}</li>
 *   <li>{@link Model.impl.EmprestimoImpl#getBorrowProtocol <em>Borrow Protocol</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EmprestimoImpl extends MinimalEObjectImpl.Container implements Emprestimo {
	/**
	 * The default value of the '{@link #getDevolutionDate() <em>Devolution Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDevolutionDate()
	 * @generated
	 * @ordered
	 */
	protected static final String DEVOLUTION_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDevolutionDate() <em>Devolution Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDevolutionDate()
	 * @generated
	 * @ordered
	 */
	protected String devolutionDate = DEVOLUTION_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getBorrowProtocol() <em>Borrow Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBorrowProtocol()
	 * @generated
	 * @ordered
	 */
	protected static final int BORROW_PROTOCOL_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getBorrowProtocol() <em>Borrow Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBorrowProtocol()
	 * @generated
	 * @ordered
	 */
	protected int borrowProtocol = BORROW_PROTOCOL_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EmprestimoImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelPackage.Literals.EMPRESTIMO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDevolutionDate() {
		return devolutionDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDevolutionDate(String newDevolutionDate) {
		String oldDevolutionDate = devolutionDate;
		devolutionDate = newDevolutionDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EMPRESTIMO__DEVOLUTION_DATE, oldDevolutionDate, devolutionDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getBorrowProtocol() {
		return borrowProtocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBorrowProtocol(int newBorrowProtocol) {
		int oldBorrowProtocol = borrowProtocol;
		borrowProtocol = newBorrowProtocol;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EMPRESTIMO__BORROW_PROTOCOL, oldBorrowProtocol, borrowProtocol));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean getDevollutionCharges(int CPF) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAvaiable(int LibNum) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDevolutionDate() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBorrowProtocol() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void cancelReservation(int BorrowProtocol) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void addReservation(int LibNum) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCharges() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ModelPackage.EMPRESTIMO__DEVOLUTION_DATE:
				return getDevolutionDate();
			case ModelPackage.EMPRESTIMO__BORROW_PROTOCOL:
				return getBorrowProtocol();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ModelPackage.EMPRESTIMO__DEVOLUTION_DATE:
				setDevolutionDate((String)newValue);
				return;
			case ModelPackage.EMPRESTIMO__BORROW_PROTOCOL:
				setBorrowProtocol((Integer)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ModelPackage.EMPRESTIMO__DEVOLUTION_DATE:
				setDevolutionDate(DEVOLUTION_DATE_EDEFAULT);
				return;
			case ModelPackage.EMPRESTIMO__BORROW_PROTOCOL:
				setBorrowProtocol(BORROW_PROTOCOL_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ModelPackage.EMPRESTIMO__DEVOLUTION_DATE:
				return DEVOLUTION_DATE_EDEFAULT == null ? devolutionDate != null : !DEVOLUTION_DATE_EDEFAULT.equals(devolutionDate);
			case ModelPackage.EMPRESTIMO__BORROW_PROTOCOL:
				return borrowProtocol != BORROW_PROTOCOL_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case ModelPackage.EMPRESTIMO___GET_DEVOLLUTION_CHARGES__INT:
				return getDevollutionCharges((Integer)arguments.get(0));
			case ModelPackage.EMPRESTIMO___IS_AVAIABLE__INT:
				return isAvaiable((Integer)arguments.get(0));
			case ModelPackage.EMPRESTIMO___SET_DEVOLUTION_DATE:
				setDevolutionDate();
				return null;
			case ModelPackage.EMPRESTIMO___SET_BORROW_PROTOCOL:
				setBorrowProtocol();
				return null;
			case ModelPackage.EMPRESTIMO___CANCEL_RESERVATION__INT:
				cancelReservation((Integer)arguments.get(0));
				return null;
			case ModelPackage.EMPRESTIMO___ADD_RESERVATION__INT:
				addReservation((Integer)arguments.get(0));
				return null;
			case ModelPackage.EMPRESTIMO___SET_CHARGES:
				setCharges();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (DevolutionDate: ");
		result.append(devolutionDate);
		result.append(", BorrowProtocol: ");
		result.append(borrowProtocol);
		result.append(')');
		return result.toString();
	}

} //EmprestimoImpl
