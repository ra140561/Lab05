/**
 */
package Model;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Departamentos</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Model.ModelPackage#getDepartamentos()
 * @model abstract="true"
 * @generated
 */
public interface Departamentos extends EObject {
} // Departamentos
