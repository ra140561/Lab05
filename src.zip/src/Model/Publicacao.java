/**
 */
package Model;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Publicacao</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Model.Publicacao#getLibNumber <em>Lib Number</em>}</li>
 * </ul>
 * </p>
 *
 * @see Model.ModelPackage#getPublicacao()
 * @model
 * @generated
 */
public interface Publicacao extends EObject {
	/**
	 * Returns the value of the '<em><b>Lib Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lib Number</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lib Number</em>' attribute.
	 * @see #setLibNumber(int)
	 * @see Model.ModelPackage#getPublicacao_LibNumber()
	 * @model dataType="org.eclipse.uml2.types.Integer" required="true" ordered="false"
	 * @generated
	 */
	int getLibNumber();

	/**
	 * Sets the value of the '{@link Model.Publicacao#getLibNumber <em>Lib Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lib Number</em>' attribute.
	 * @see #getLibNumber()
	 * @generated
	 */
	void setLibNumber(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model LibNumDataType="org.eclipse.uml2.types.Integer" LibNumRequired="true" LibNumOrdered="false"
	 * @generated
	 */
	void addNewPublication(int LibNum);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model LibNumDataType="org.eclipse.uml2.types.Integer" LibNumRequired="true" LibNumOrdered="false"
	 * @generated
	 */
	void removePublication(int LibNum);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 * @generated
	 */
	void getLibnumber();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setLibnumber();

} // Publicacao
