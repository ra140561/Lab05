/**
 */
package Model;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Emprestimo</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Model.Emprestimo#getDevolutionDate <em>Devolution Date</em>}</li>
 *   <li>{@link Model.Emprestimo#getBorrowProtocol <em>Borrow Protocol</em>}</li>
 * </ul>
 * </p>
 *
 * @see Model.ModelPackage#getEmprestimo()
 * @model
 * @generated
 */
public interface Emprestimo extends EObject {
	/**
	 * Returns the value of the '<em><b>Devolution Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Devolution Date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Devolution Date</em>' attribute.
	 * @see #setDevolutionDate(String)
	 * @see Model.ModelPackage#getEmprestimo_DevolutionDate()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getDevolutionDate();

	/**
	 * Sets the value of the '{@link Model.Emprestimo#getDevolutionDate <em>Devolution Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Devolution Date</em>' attribute.
	 * @see #getDevolutionDate()
	 * @generated
	 */
	void setDevolutionDate(String value);

	/**
	 * Returns the value of the '<em><b>Borrow Protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Borrow Protocol</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Borrow Protocol</em>' attribute.
	 * @see #setBorrowProtocol(int)
	 * @see Model.ModelPackage#getEmprestimo_BorrowProtocol()
	 * @model dataType="org.eclipse.uml2.types.Integer" required="true" ordered="false"
	 * @generated
	 */
	int getBorrowProtocol();

	/**
	 * Sets the value of the '{@link Model.Emprestimo#getBorrowProtocol <em>Borrow Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Borrow Protocol</em>' attribute.
	 * @see #getBorrowProtocol()
	 * @generated
	 */
	void setBorrowProtocol(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="org.eclipse.uml2.types.Boolean" required="true" ordered="false" CPFDataType="org.eclipse.uml2.types.Integer" CPFRequired="true" CPFOrdered="false"
	 * @generated
	 */
	boolean getDevollutionCharges(int CPF);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model dataType="org.eclipse.uml2.types.Boolean" required="true" ordered="false" LibNumDataType="org.eclipse.uml2.types.Integer" LibNumRequired="true" LibNumOrdered="false"
	 * @generated
	 */
	boolean isAvaiable(int LibNum);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setDevolutionDate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setBorrowProtocol();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model BorrowProtocolDataType="org.eclipse.uml2.types.Integer" BorrowProtocolRequired="true" BorrowProtocolOrdered="false"
	 * @generated
	 */
	void cancelReservation(int BorrowProtocol);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model LibNumDataType="org.eclipse.uml2.types.Integer" LibNumRequired="true" LibNumOrdered="false"
	 * @generated
	 */
	void addReservation(int LibNum);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setCharges();

} // Emprestimo
